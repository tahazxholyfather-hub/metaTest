import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Check, AlertCircle, Loader2 } from 'lucide-react';
import { MathRenderer } from '../../components/ui/MathRenderer';
import { QuestionCounter } from '../../components/QuestionCounter';
import { CountdownTimer } from '../../components/QuizTimerCountDown';
import { ResponsiveModal } from '../../components/ResponsiveModal';
import { flowApi } from '../../lib/authApi';
import { useUser } from '../../context/UserContext';
import { useSocket } from '../../socket/useSocket';
import { useLobbyEvents } from '../../socket/useLobbyEvents';
import {
    joinLobby,
    leaveLobby,
    submitQuiz,
    updateMemberProgress,
    SocketRequestError,
} from '../../socket/lobby.socket';
import type { LobbyState, QuizResult } from '../../socket/types';

// --- Real-time Avatar Progress Interfaces & Sub-Components ---
interface AvatarData {
    id: string | number;
    imageUrl: string;
    name: string;
    progress: number; // 0 to 100
}

interface AvatarListProps {
    avatars: AvatarData[];
}

interface AvatarWithProgressProps {
    avatar: AvatarData;
    size?: number;
    strokeWidth?: number;
}

const AvatarWithProgress: React.FC<AvatarWithProgressProps> = ({
                                                                   avatar,
                                                                   size = 64,
                                                                   strokeWidth = 3,
                                                               }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const strokeDashoffset = circumference - (avatar.progress / 100) * circumference;

    const isCompleted = avatar.progress === 100;

    return (
        <div className="relative flex flex-col items-center gap-2 shrink-0 snap-start cursor-pointer">
            {/* Avatar Container */}
            <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="relative flex items-center justify-center"
                style={{ width: size, height: size }}
            >
                {/* Background & Progress SVG */}
                <svg
                    className="absolute top-0 left-0 -rotate-90"
                    width={size}
                    height={size}
                    viewBox={`0 0 ${size} ${size}`}
                >
                    {/* Track Circle */}
                    <circle
                        style={{ color: 'var(--border)' }}
                        strokeWidth={strokeWidth}
                        stroke="currentColor"
                        fill="transparent"
                        r={radius}
                        cx={size / 2}
                        cy={size / 2}
                    />
                    {/* Animated Progress Circle */}
                    <motion.circle
                        style={{ color: 'var(--accent)' }}
                        strokeWidth={strokeWidth}
                        strokeDasharray={circumference}
                        initial={{ strokeDashoffset: circumference }}
                        animate={{ strokeDashoffset }}
                        transition={{ duration: 1.2, ease: "easeOut" }}
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="transparent"
                        r={radius}
                        cx={size / 2}
                        cy={size / 2}
                    />
                </svg>

                {/* Inner Image Container */}
                <div
                    className="relative rounded-full overflow-hidden border-2 border-transparent"
                    style={{
                        width: size - strokeWidth * 3,
                        height: size - strokeWidth * 3
                    }}
                >
                    <img
                        src={avatar.imageUrl}
                        alt={avatar.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                    />

                    {/* 100% Completion Layer */}
                    {isCompleted && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.8, duration: 0.4 }}
                            className="absolute inset-0 flex items-center justify-center backdrop-blur-[2px]"
                            style={{ backgroundColor: 'var(--active-overlay)' }}
                        >
                            <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.9 }}
                                style={{
                                    backgroundColor: 'var(--success)',
                                    color: 'var(--text-inverse)'
                                }}
                                className="p-1 rounded-full shadow-md"
                            >
                                <Check size={12} strokeWidth={3} />
                            </motion.div>
                        </motion.div>
                    )}
                </div>
            </motion.div>

            {/* Name Label */}
            <span
                className="text-xs font-medium truncate w-25 text-center text-zinc-500 dark:text-zinc-400"
            >
                {avatar.name}
            </span>
        </div>
    );
};

const AvatarList: React.FC<AvatarListProps> = ({ avatars }) => {
    return (
        <div className="w-full py-2">
            <div className="flex items-center gap-5 overflow-x-auto snap-x snap-mandatory pb-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                {avatars.map((avatar) => (
                    <AvatarWithProgress
                        key={avatar.id}
                        avatar={avatar}
                        size={64}
                        strokeWidth={3}
                    />
                ))}
            </div>
        </div>
    );
};

// --- Core Helper Functions ---
type Option = {
    id: number;
    text: string;
    subject_id?: number;
};

type Question = {
    id: number;
    text: string;
    options: Option[];
    subject: string;
    subject_id?: number;
    grade?: string;
    topic?: string;
    chapter?: string;
    level: string;
    has_image?: boolean;
    image_url?: string | null;
    correct_option_id?: number;
    descriptive_answer?: string;
    points_earned?: number;
};

type SelectionLog = {
    questionId: number;
    optionId: number;
    timeSpentMs: number;
    timestamp: number;
};

type StoredQuizSession = {
    quizId: string;
    userId: string | number;
    answers: Record<number, number>;
    questionTimes: Record<number, number>;
    selectionLog: SelectionLog[];
    quizStartTime: number;
    expiresAt: number;
};

interface QuizPageProps {
    quizData?: any;
    onExit?: () => void;
}

const butteryEase = [0.22, 1, 0.36, 1];

const decodeHtmlEntities = (text: string) => {
    if (!text) return '';
    const txt = document.createElement('textarea');
    txt.innerHTML = text;
    return txt.value
        .replace(/\u200c|\u200d|\u200e|\u200f|\ufeff/g, '')
        .replace(/&zwnj;|&zwj;|&lrm;|&rlm;|&nbsp;/gi, ' ')
        .replace(/[ \t]+/g, ' ')
        .trim();
};

function getErrorMessage(err: unknown, fallback = 'خطای نامشخص رخ داد.') {
    if (
        typeof err === 'object' &&
        err !== null &&
        'message' in err &&
        typeof (err as { message?: unknown }).message === 'string'
    ) {
        return (err as { message: string }).message;
    }
    return fallback;
}

function isTruthyMemberResponse(response: any): boolean {
    return Boolean(
        response?.isMember ??
        response?.data?.isMember ??
        response?.result?.isMember ??
        response?.member ??
        response?.data?.member ??
        response?.success
    );
}

function getLobbyMembers(lobbyState: any): any[] {
    if (Array.isArray(lobbyState?.members)) return lobbyState.members;
    if (Array.isArray(lobbyState?.data?.members)) return lobbyState.data.members;
    return [];
}

function isUserInsideLobbyMembers(lobbyState: any, userId: string | number): boolean {
    const members = getLobbyMembers(lobbyState);
    return members.some((member) => {
        return (
            String(member?.userId) === String(userId) ||
            String(member?.id) === String(userId) ||
            String(member?.user?.id) === String(userId)
        );
    });
}

function getLobbyStatus(lobbyState: any): string {
    return String(lobbyState?.status ?? lobbyState?.data?.status ?? '').toLowerCase();
}

function getLobbyJoinLocked(lobbyState: any): boolean {
    return Boolean(lobbyState?.joinLocked ?? lobbyState?.data?.joinLocked);
}

function getLobbyCodeFromQuizData(quizData: any, fallback: string): string {
    return String(
        quizData?.code ??
        quizData?.lobbyCode ??
        quizData?.lobby?.code ??
        fallback
    );
}

function validateLobbyAccess(lobbyState: any, currentUserId: string | number): string | null {
    const status = getLobbyStatus(lobbyState);
    const joinLocked = getLobbyJoinLocked(lobbyState);
    const isInMembers = isUserInsideLobbyMembers(lobbyState, currentUserId);

    const closedStatuses = ['closed', 'ended', 'finished', 'expired', 'destroyed'];

    if (closedStatuses.includes(status)) {
        return 'لابی این آزمون بسته شده یا آزمون به پایان رسیده است.';
    }

    if (status === 'started' && !isInMembers) {
        return 'آزمون شروع شده است و امکان ورود جدید وجود ندارد.';
    }

    if (joinLocked && !isInMembers) {
        return 'ورود به لابی قفل شده است.';
    }

    return null;
}

function FilterPill({ prefix, active, onClick, label }: { prefix: string; active: boolean; onClick: () => void; label: string; }) {
    return (
        <button onClick={onClick} className="relative px-4 py-1.5 text-sm font-semibold transition-colors shrink-0 whitespace-nowrap">
            {active && (
                <motion.div layoutId={`${prefix}-activeFilterPill`} className="absolute inset-0 bg-[var(--accent)] rounded-full" transition={{ type: 'spring', stiffness: 400, damping: 30 }} />
            )}
            <span className={`relative z-10 transition-colors ${active ? 'text-white' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}>
                {label}
            </span>
        </button>
    );
}

function Skeleton({ className }: { className?: string }) {
    return (
        <div className={`relative overflow-hidden rounded-md bg-zinc-200/80 dark:bg-zinc-800/80 ${className || ''}`}>
            <motion.div className="absolute inset-0 z-10 bg-gradient-to-r from-transparent via-white/60 dark:via-white/10 to-transparent" style={{ width: '150%', skewX: '-15deg' }} animate={{ translateX: ['-100%', '150%'] }} transition={{ duration: 1.5, repeat: Infinity, ease: [0.4, 0.0, 0.2, 1] }} />
        </div>
    );
}

const FilterGroup = ({
                         prefix,
                         activeFilter,
                         setActiveFilter,
                         subjects
                     }: {
    prefix: string;
    activeFilter: string;
    setActiveFilter: (f: string) => void;
    subjects: { id: number, name: string }[]
}) => (
    <>
        <FilterPill prefix={prefix} active={activeFilter === 'all'} onClick={() => setActiveFilter('all')} label="همه" />
        <FilterPill prefix={prefix} active={activeFilter === 'answered'} onClick={() => setActiveFilter('answered')} label="پاسخ داده" />
        <FilterPill prefix={prefix} active={activeFilter === 'unanswered'} onClick={() => setActiveFilter('unanswered')} label="نزده" />
        {subjects.length > 1 && (
            <>
                <div className="w-px h-4 bg-zinc-300 dark:bg-zinc-700 mx-1 shrink-0" />
                {subjects.map((sub) => (
                    <FilterPill key={`sub_${sub.id}`} prefix={prefix} active={activeFilter === `sub_${sub.id}`} onClick={() => setActiveFilter(`sub_${sub.id}`)} label={sub.name} />
                ))}
            </>
        )}
    </>
);

export default function QuizPage({ quizData: initialQuizData }: QuizPageProps) {
    const navigate = useNavigate();
    const { quizId } = useParams();
    const hashedQuizId = quizId || '';

    const { user, isAuthenticated, isAuthLoading } = useUser();
    const currentUserId = user?.id ?? null;

    const { socket, isConnected, status: socketStatus, error: socketError, connect } = useSocket();

    const hasSubmittedRef = useRef(false);
    const loadedQuizIdRef = useRef<string | null>(null);
    const joinedLobbyRef = useRef(false);
    const lobbyCodeRef = useRef<string | null>(null);
    const isPrivatePreviewRef = useRef(false);

    // --- Precise Time Tracking Refs ---
    const questionTimesRef = useRef<Record<number, number>>({});
    const selectionLogRef = useRef<SelectionLog[]>([]);
    const activeQuestionIdRef = useRef<number | null>(null);
    const lastTickTimeRef = useRef<number>(Date.now());
    const questionRefs = useRef<Record<number, HTMLElement | null>>({});

    // --- Focus Tracking Refs for Answered Questions ---
    const currentFocusDurationRef = useRef<number>(0);
    const lastActiveQuestionIdRef = useRef<number | null>(null);

    const [, setTick] = useState(0);
    const [questions, setQuestions] = useState<Question[]>([]);
    const [quizData, setQuizData] = useState<any>(initialQuizData ?? null);

    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [lobbyError, setLobbyError] = useState<string | null>(null);

    const [answers, setAnswers] = useState<Record<number, number>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [activeFilter, setActiveFilter] = useState<string>('all');

    const [quizStartTime, setQuizStartTime] = useState<number>(Date.now());
    const [remainingSeconds, setRemainingSeconds] = useState<number>(0);
    const [isSessionReady, setIsSessionReady] = useState<boolean>(false);
    const [timeLimitSecs, setTimeLimitSecs] = useState<number>(20 * 60);

    const [lobbyState, setLobbyState] = useState<LobbyState | null>(null);
    const [joinedLobby, setJoinedLobby] = useState(false);

    const baseImageUrl = '/images/questions/';

    useEffect(() => {
        joinedLobbyRef.current = joinedLobby;
    }, [joinedLobby]);

    const storageKey = useMemo(() => {
        if (!hashedQuizId || !currentUserId) return '';
        return `quiz_session_${currentUserId}_${hashedQuizId}`;
    }, [currentUserId, hashedQuizId]);

    const clearStoredSession = useCallback(() => {
        if (!storageKey) return;
        localStorage.removeItem(storageKey);
    }, [storageKey]);

    const saveSession = useCallback(
        (nextAnswers: Record<number, number>, startTime: number) => {
            if (!storageKey || !hashedQuizId || !currentUserId) return;
            const expiresAt = startTime + timeLimitSecs * 1000;
            const payload: StoredQuizSession = {
                quizId: hashedQuizId,
                userId: currentUserId,
                answers: nextAnswers,
                questionTimes: questionTimesRef.current,
                selectionLog: selectionLogRef.current,
                quizStartTime: startTime,
                expiresAt
            };
            localStorage.setItem(storageKey, JSON.stringify(payload));
        },
        [storageKey, hashedQuizId, currentUserId, timeLimitSecs]
    );

    const subjects = useMemo(() => {
        const subs = new Map<number, string>();
        questions.forEach((q) => {
            if (q.subject_id && q.subject) subs.set(q.subject_id, q.subject);
        });
        return Array.from(subs.entries()).map(([id, name]) => ({ id, name }));
    }, [questions]);

    const filteredQuestions = useMemo(() => {
        return questions.filter((q) => {
            let passFilter = true;
            if (activeFilter === 'answered') passFilter = answers[q.id] !== undefined;
            else if (activeFilter === 'unanswered') passFilter = answers[q.id] === undefined;
            else if (activeFilter.startsWith('sub_')) passFilter = q.subject_id === parseInt(activeFilter.replace('sub_', ''), 10);
            return passFilter;
        });
    }, [answers, activeFilter, questions]);

    // --- High Accuracy Desktop/Mobile Intersection Observer ---
    useEffect(() => {
        if (isLoading || questions.length === 0) return;

        const observerOptions = {
            root: null,
            rootMargin: '-30% 0px -30% 0px',
            threshold: Array.from({ length: 11 }, (_, i) => i * 0.1),
        };

        const observer = new IntersectionObserver((entries) => {
            let mostVisibleId: number | null = null;
            let maxRatio = 0;

            entries.forEach(entry => {
                if (entry.isIntersecting && entry.intersectionRatio > maxRatio) {
                    maxRatio = entry.intersectionRatio;
                    const elId = entry.target.getAttribute('data-question-id');
                    if (elId) mostVisibleId = Number(elId);
                }
            });

            if (mostVisibleId !== null && maxRatio > 0) {
                activeQuestionIdRef.current = mostVisibleId;
            }
        }, observerOptions);

        Object.values(questionRefs.current).forEach((el) => {
            if (el) observer.observe(el);
        });

        return () => observer.disconnect();
    }, [isLoading, questions, filteredQuestions]);

    // --- Precision Timer Interval Loop with Answer Focus Logic ---
    useEffect(() => {
        if (isLoading || !isSessionReady || hasSubmittedRef.current) return;

        lastTickTimeRef.current = Date.now();

        const interval = setInterval(() => {
            const now = Date.now();
            const delta = now - lastTickTimeRef.current;
            lastTickTimeRef.current = now;

            const activeId = activeQuestionIdRef.current;

            if (activeId !== null) {
                if (activeId !== lastActiveQuestionIdRef.current) {
                    lastActiveQuestionIdRef.current = activeId;
                    currentFocusDurationRef.current = 0;
                } else {
                    currentFocusDurationRef.current += delta;
                }

                const isAnswered = answers[activeId] !== undefined;

                if (!isAnswered) {
                    questionTimesRef.current[activeId] = (questionTimesRef.current[activeId] || 0) + delta;
                } else {
                    if (currentFocusDurationRef.current > 5000) {
                        questionTimesRef.current[activeId] = (questionTimesRef.current[activeId] || 0) + delta;
                    }
                }
            } else {
                lastActiveQuestionIdRef.current = null;
                currentFocusDurationRef.current = 0;
            }

            setTick(t => t + 1);
        }, 1000);

        return () => clearInterval(interval);
    }, [isLoading, isSessionReady, answers]);

    const handleLobbyState = useCallback((nextState: LobbyState) => {
        if (isPrivatePreviewRef.current) return;
        setLobbyState(nextState);
        if (!currentUserId) return;
        const accessError = validateLobbyAccess(nextState, currentUserId);
        if (accessError) setLobbyError(accessError);
        else setLobbyError(null);
    }, [currentUserId]);

    const handleLobbyStarted = useCallback((nextState: LobbyState) => {
        if (isPrivatePreviewRef.current) return;
        setLobbyState(nextState);
        if (!currentUserId) return;
        const accessError = validateLobbyAccess(nextState, currentUserId);
        if (accessError) setLobbyError(accessError);
        else setLobbyError(null);
    }, [currentUserId]);

    const handleLobbyDestroyed = useCallback((payload: { code: string; reason?: string }) => {
        if (isPrivatePreviewRef.current) return;
        setLobbyError(payload?.reason || 'لابی آزمون حذف یا بسته شده است.');
        setJoinedLobby(false);
    }, []);

    const handleKicked = useCallback((payload: { code: string; userId?: string; reason?: string }) => {
        if (isPrivatePreviewRef.current) return;
        if (!currentUserId) return;
        if (!payload?.userId || String(payload.userId) === String(currentUserId)) {
            setLobbyError(payload?.reason || 'شما از لابی آزمون خارج شدید.');
            setJoinedLobby(false);
        }
    }, [currentUserId]);

    const handleMemberJoined = useCallback((nextState: LobbyState) => { if (!isPrivatePreviewRef.current) setLobbyState(nextState); }, []);
    const handleMemberLeft = useCallback((nextState: LobbyState) => { if (!isPrivatePreviewRef.current) setLobbyState(nextState); }, []);
    const handleMemberUpdated = useCallback((nextState: LobbyState) => { if (!isPrivatePreviewRef.current) setLobbyState(nextState); }, []);
    const handleMemberProgress = useCallback((payload: any) => {
        if (isPrivatePreviewRef.current || !payload) return;

        // If backend sends a full lobby snapshot, replace normally.
        if (payload?.members || payload?.data?.members || payload?.status) {
            setLobbyState(payload);
            return;
        }

        const progressUserId = payload?.userId ?? payload?.id ?? payload?.memberId;
        if (!progressUserId) return;

        setLobbyState((prevState: any) => {
            if (!prevState) return prevState;

            const members = getLobbyMembers(prevState);
            const nextMembers = members.map((member) => {
                const memberId = member?.userId ?? member?.id ?? member?.user?.id;

                if (String(memberId) !== String(progressUserId)) {
                    return member;
                }

                return {
                    ...member,
                    answeredCount: payload?.answeredCount ?? member?.answeredCount ?? 0,
                    totalQuestions: payload?.totalQuestions ?? member?.totalQuestions ?? questions.length,
                    progress: payload?.progress ?? member?.progress,
                };
            });

            if (Array.isArray(prevState?.members)) {
                return {
                    ...prevState,
                    members: nextMembers,
                };
            }

            if (Array.isArray(prevState?.data?.members)) {
                return {
                    ...prevState,
                    data: {
                        ...prevState.data,
                        members: nextMembers,
                    },
                };
            }

            return prevState;
        });
    }, [questions.length]);


    const handleQuizResult = useCallback((payload: QuizResult) => { console.log('Quiz result event:', payload); }, []);

    const handleLobbyError = useCallback((err: any) => {
        if (isPrivatePreviewRef.current) return;
        setLobbyError(err?.message || 'خطای لابی رخ داد.');
    }, []);

    useLobbyEvents({
        socket,
        onLobbyState: handleLobbyState,
        onLobbyStarted: handleLobbyStarted,
        onLobbyDestroyed: handleLobbyDestroyed,
        onKicked: handleKicked,
        onMemberJoined: handleMemberJoined,
        onMemberLeft: handleMemberLeft,
        onMemberUpdated: handleMemberUpdated,
        onMemberProgress: handleMemberProgress,
        onQuizResult: handleQuizResult,
        onLobbyError: handleLobbyError,
    });

    useEffect(() => {
        let isMounted = true;

        const initQuiz = async () => {
            if (isAuthLoading) return;

            if (loadedQuizIdRef.current === hashedQuizId) {
                return;
            }

            if (!isAuthenticated || !currentUserId) {
                if (isMounted) {
                    setError('برای ورود به آزمون باید وارد حساب کاربری شوید.');
                    setIsLoading(false);
                }
                return;
            }

            if (!hashedQuizId || typeof hashedQuizId !== 'string') {
                if (isMounted) {
                    setError('شناسه آزمون نامعتبر است.');
                    setIsLoading(false);
                }
                return;
            }

            try {
                setIsLoading(true);
                setIsSessionReady(false);
                setError(null);
                setLobbyError(null);

                const infoResponse = await flowApi.dispatch('get_quiz_info', { quizId: hashedQuizId });
                if (!isMounted) return;

                const quizInfo = infoResponse?.data || infoResponse || {};
                const visibility = quizInfo?.visibility;
                const creatorId = quizInfo?.creator_id;
                const status = quizInfo?.status;
                const apiTimeLimit = quizInfo?.time_limit;

                const isPrivateCreatorWaiting = visibility === 'private' && String(creatorId) === String(currentUserId) && status === 'in_progress';
                isPrivatePreviewRef.current = isPrivateCreatorWaiting;

                let nextQuizData = initialQuizData || {};
                let effectiveTimeSecs = 20 * 60;

                if (!isPrivateCreatorWaiting) {
                    const memberResponse = await flowApi.dispatch('check_user_member', { quizId: hashedQuizId, userId: currentUserId });
                    if (!isMounted) return;

                    const isMember = isTruthyMemberResponse(memberResponse);
                    if (!isMember) {
                        setError('شما عضو این آزمون نیستید.');
                        setIsLoading(false);
                        return;
                    }

                    let activeSocket = socket;
                    if (!activeSocket || !activeSocket.connected) {
                        activeSocket = connect();
                        if (!activeSocket) {
                            setError('اتصال realtime برقرار نشد.');
                            setIsLoading(false);
                            return;
                        }
                    }

                    const fallbackLobbyCode = quizInfo?.code || quizInfo?.lobbyCode;
                    const lobbyCode = getLobbyCodeFromQuizData(initialQuizData, fallbackLobbyCode || hashedQuizId);
                    lobbyCodeRef.current = lobbyCode;

                    const joinedState = await joinLobby(activeSocket, { code: lobbyCode, quizId: hashedQuizId, userId: String(currentUserId) } as any);
                    if (!isMounted) return;

                    const accessError = validateLobbyAccess(joinedState, currentUserId);
                    if (accessError) {
                        setError(accessError);
                        setLobbyError(accessError);
                        setIsLoading(false);
                        return;
                    }

                    setLobbyState(joinedState);
                    setJoinedLobby(true);

                    const response = await flowApi.dispatch('get_quiz_questions', { quizId: hashedQuizId, userId: currentUserId });
                    if (!isMounted) return;

                    if (!response?.success) {
                        setError(response?.message || 'خطا در دریافت سوالات');
                        setIsLoading(false);
                        return;
                    }

                    const rawQuestions = response?.questions || response?.data?.questions || [];
                    nextQuizData = response?.quiz || response?.data?.quiz || initialQuizData || quizInfo || {};
                    effectiveTimeSecs = (nextQuizData?.setting?.time || nextQuizData?.settings?.time || 20) * 60;

                    setQuizData(nextQuizData);
                    setQuestions(rawQuestions.map((q: any) => ({
                        id: q.id,
                        text: decodeHtmlEntities(q.text || ''),
                        level: q.difficulty_level || q.level || '',
                        subject_id: q.subject_id,
                        subject: q.subject || '',
                        grade: q.grade,
                        topic: q.topic,
                        chapter: q.chapter,
                        options: q.options || [],
                        has_image: q.has_image,
                        image_url: q.images?.length ? q.images[0] : q.image_url || null
                    })));
                } else {
                    const response = await flowApi.dispatch('get_quiz_questions', { quizId: hashedQuizId, userId: currentUserId });
                    if (!isMounted) return;

                    if (!response?.success) {
                        setError(response?.message || 'خطا در دریافت سوالات');
                        setIsLoading(false);
                        return;
                    }

                    const rawQuestions = response?.questions || response?.data?.questions || [];
                    nextQuizData = response?.quiz || response?.data?.quiz || initialQuizData || quizInfo || {};
                    effectiveTimeSecs = (apiTimeLimit || nextQuizData?.time_limit || 20) * 60;

                    setQuizData(nextQuizData);
                    setQuestions(rawQuestions.map((q: any) => ({
                        id: q.id,
                        text: decodeHtmlEntities(q.text || ''),
                        level: q.difficulty_level || q.level || '',
                        subject_id: q.subject_id,
                        subject: q.subject || '',
                        grade: q.grade,
                        topic: q.topic,
                        chapter: q.chapter,
                        options: q.options || [],
                        has_image: q.has_image,
                        image_url: q.images?.length ? q.images[0] : q.image_url || null
                    })));
                }

                setTimeLimitSecs(effectiveTimeSecs);

                let restoredAnswers: Record<number, number> = {};
                let restoredStartTime = Date.now();

                if (storageKey) {
                    const raw = localStorage.getItem(storageKey);
                    if (raw) {
                        try {
                            const parsed: StoredQuizSession = JSON.parse(raw);
                            const now = Date.now();
                            const isValidSession =
                                parsed?.quizId === hashedQuizId &&
                                String(parsed?.userId) === String(currentUserId) &&
                                typeof parsed?.quizStartTime === 'number' &&
                                typeof parsed?.expiresAt === 'number' &&
                                parsed.expiresAt > now;

                            if (isValidSession) {
                                restoredAnswers = parsed.answers || {};
                                questionTimesRef.current = parsed.questionTimes || {};
                                selectionLogRef.current = parsed.selectionLog || [];
                                restoredStartTime = parsed.quizStartTime;
                            } else {
                                localStorage.removeItem(storageKey);
                            }
                        } catch {
                            localStorage.removeItem(storageKey);
                        }
                    }
                }

                const elapsedSeconds = Math.floor((Date.now() - restoredStartTime) / 1000);
                const nextRemainingSeconds = Math.max(effectiveTimeSecs - elapsedSeconds, 0);

                if (nextRemainingSeconds <= 0) {
                    clearStoredSession();
                    setError('زمان این آزمون به پایان رسیده است.');
                    setIsLoading(false);
                    return;
                }

                setAnswers(restoredAnswers);
                setQuizStartTime(restoredStartTime);
                setRemainingSeconds(nextRemainingSeconds);

                saveSession(restoredAnswers, restoredStartTime);

                if (isMounted) {
                    loadedQuizIdRef.current = hashedQuizId;
                }
                setIsSessionReady(true);

            } catch (err: unknown) {
                console.error('Error initializing quiz:', err);
                if (!isMounted) return;
                const message = err instanceof SocketRequestError ? err.message : getErrorMessage(err, 'خطا در بارگذاری آزمون.');
                setError(message);
                setLobbyError(message);
            } finally {
                if (isMounted) setIsLoading(false);
            }
        };

        initQuiz();

        return () => { isMounted = false; };
    }, [isAuthLoading, isAuthenticated, currentUserId, hashedQuizId, storageKey, socket, connect, clearStoredSession, saveSession, initialQuizData]);

    useEffect(() => {
        if (!storageKey || !hashedQuizId || !isSessionReady || isLoading || hasSubmittedRef.current) return;
        const expiresAt = quizStartTime + timeLimitSecs * 1000;
        if (Date.now() >= expiresAt) {
            clearStoredSession();
            return;
        }
        saveSession(answers, quizStartTime);
    }, [answers, quizStartTime, saveSession, storageKey, hashedQuizId, isSessionReady, isLoading, timeLimitSecs, clearStoredSession]);

    useEffect(() => {
        return () => {
            if (socket && joinedLobbyRef.current && lobbyCodeRef.current && currentUserId && !isPrivatePreviewRef.current) {
                leaveLobby(socket, { code: lobbyCodeRef.current, userId: String(currentUserId) } as any).catch(() => {});
            }
        };
    }, [socket, currentUserId]);

    const triggerSubmit = useCallback(async () => {
        if (isSubmitting || hasSubmittedRef.current) return;

        if (!hashedQuizId || typeof hashedQuizId !== 'string') {
            setError('شناسه آزمون نامعتبر است.');
            return;
        }

        if (!currentUserId) {
            setError('کاربر معتبر نیست.');
            return;
        }

        hasSubmittedRef.current = true;
        setIsSubmitting(true);
        setError(null);

        try {
            const secondsSpent = Math.max(0, Date.now() - quizStartTime);
            const questionIds = questions.map((q) => q.id);

            const payload = {
                quizId: hashedQuizId,
                userId: currentUserId,
                answers,
                questionIds,
                timeSpent: secondsSpent,
                questionTimes: questionTimesRef.current,
                selectionLog: selectionLogRef.current
            };

            let response: any;

            if (isPrivatePreviewRef.current) {
                response = await flowApi.dispatch('submit_quiz_answers', payload);
            } else {
                if (!socket || !lobbyCodeRef.current) throw new Error('اتصال لابی برقرار نیست.');
                response = await submitQuiz(socket, {
                    ...payload,
                    code: lobbyCodeRef.current,
                    userId: String(currentUserId),
                } as any);
            }

            clearStoredSession();

            const resultId =
                response?.result_id ??
                response?.resultId ??
                response?.data?.result_id ??
                response?.data?.resultId ??
                response?.summary?.result_id ??
                response?.summary?.resultId;

            const responseData = response?.data ?? {};
            const resultQuestions = questions.map((q) => {
                const resultData = responseData?.[q.id];
                if (resultData) {
                    return {
                        ...q,
                        correct_option_id: resultData.correct_option_id,
                        descriptive_answer: resultData.descriptive_answer?.text,
                        points_earned: resultData.points_earned
                    };
                }
                return q;
            });

            if (resultId) {
                navigate(`/result/${resultId}`, {
                    replace: true,
                    state: {
                        quizId: hashedQuizId,
                        userId: currentUserId,
                        resultId,
                        quizSummary: response?.summary || null,
                        questions: resultQuestions,
                        answers,
                        quizData
                    }
                });
                return;
            }

            setError('شناسه نتیجه از سمت سرور دریافت نشد.');
            hasSubmittedRef.current = false;
        } catch (err: unknown) {
            console.error('Submit Error:', err);
            const message = err instanceof SocketRequestError ? err.message : getErrorMessage(err, 'مشکلی در ارتباط با سرور هنگام ثبت آزمون پیش آمد.');
            setError(message);
            hasSubmittedRef.current = false;
        } finally {
            setIsSubmitting(false);
        }
    }, [socket, answers, isSubmitting, navigate, hashedQuizId, questions, quizData, quizStartTime, clearStoredSession, currentUserId]);

    const handleTimeUp = useCallback(() => {
        clearStoredSession();
        triggerSubmit();
    }, [triggerSubmit, clearStoredSession]);

    const confirmFinish = useCallback(() => {
        setIsModalOpen(false);
        triggerSubmit();
    }, [triggerSubmit]);

    const handleSelectAnswer = useCallback((questionId: number, optionId: number) => {
        activeQuestionIdRef.current = questionId;
        lastActiveQuestionIdRef.current = questionId;
        currentFocusDurationRef.current = 0;

        const now = Date.now();
        const exactTimeSpent = questionTimesRef.current[questionId] || 0;

        selectionLogRef.current.push({
            questionId,
            optionId,
            timeSpentMs: exactTimeSpent,
            timestamp: now
        });

        setAnswers((prev) => {
            const nextAnswers = { ...prev, [questionId]: optionId };
            if (!isPrivatePreviewRef.current && socket && joinedLobbyRef.current && currentUserId && hashedQuizId && lobbyCodeRef.current) {
                updateMemberProgress(socket, {
                    code: lobbyCodeRef.current,
                    quizId: hashedQuizId,
                    userId: String(currentUserId),
                    answeredCount: Object.keys(nextAnswers).length,
                    totalQuestions: questions.length,
                } as any).catch(() => {});
            }
            return nextAnswers;
        });
    }, [socket, currentUserId, hashedQuizId, questions.length]);

    // Map lobby state members' progress into AvatarData structure in real-time
    const avatarDataList = useMemo<AvatarData[]>(() => {
        if (isPrivatePreviewRef.current || !joinedLobby) return [];
        const members = getLobbyMembers(lobbyState);
        return members.map((member) => {
            const memberId = member?.userId ?? member?.id ?? member?.user?.id ?? Math.random();
            const memberName = member?.displayName ?? member?.user?.username ?? 'کاربر';

            const isSelf = String(memberId) === String(currentUserId);
            const totalQ = member?.totalQuestions || questions.length || 1;

            // Instantly use local answer counts for the active user's progress bar
            const answeredQ = isSelf ? Object.keys(answers).length : (member?.answeredCount || 0);
            const rawProgress = member?.progress;

            const progressPercent = typeof rawProgress === 'number'
                ? Math.min(100, Math.max(0, rawProgress))
                : Math.min(100, Math.max(0, (answeredQ / totalQ) * 100));


            const avatarImg = member?.imageUrl ?? member?.user?.avatar ?? member?.avatarUrl ?? `https://api.dicebear.com/7.x/fun-emoji/svg?seed=${encodeURIComponent(memberName)}`;

            return {
                id: memberId,
                imageUrl: avatarImg,
                name: memberName,
                progress: progressPercent
            };
        });
    }, [lobbyState, questions.length, joinedLobby, answers, currentUserId]);

    const visibleError = error || lobbyError || socketError;
    const isLobbyMode = !isPrivatePreviewRef.current && joinedLobby;

    if (visibleError && !isLoading && questions.length === 0) {
        return (
            <div className="min-h-screen bg-[var(--bg-app)] text-[var(--text-primary)] flex items-center justify-center px-4" dir="rtl">
                <div className="w-full max-w-md text-center space-y-5">
                    <div className="mx-auto w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-900/30 text-rose-500 flex items-center justify-center">
                        <AlertCircle size={30} />
                    </div>
                    <h1 className="text-xl font-black">خطا در بارگذاری آزمون</h1>
                    <div className="rounded-2xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-4 py-4 text-rose-600 dark:text-rose-300 text-sm font-bold">
                        {visibleError}
                    </div>
                    <button onClick={() => navigate('/', { replace: true })} className="w-full py-3 px-4 rounded-xl bg-[var(--accent)] text-white text-sm font-bold hover:bg-[var(--accent)]/90 transition-colors">
                        بازگشت به داشبورد
                    </button>
                </div>
            </div>
        );
    }

    if (isLoading) {
        return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full min-h-screen bg-[var(--bg-app)] pb-20" dir="rtl">
                <header className="sticky top-0 z-50 w-full bg-[var(--bg-app)]/90 backdrop-blur-xl border-b border-black/10 dark:border-white/10 h-16 md:h-20 flex items-center px-4 md:px-8 justify-between">
                    <div className="flex gap-2">
                        <Skeleton className="w-16 h-8 rounded-full" />
                        <Skeleton className="w-20 h-8 rounded-full" />
                    </div>
                    <Skeleton className="w-24 h-10 rounded-full" />
                </header>
                <div className="max-w-7xl mx-auto px-4 pt-6 md:pt-12 space-y-12">
                    {[1, 2, 3].map((i) => (
                        <div key={i} className="w-full pb-12 mb-12 border-b border-zinc-200 dark:border-zinc-800 last:border-0">
                            <div className="flex items-center gap-4 mb-6">
                                <Skeleton className="w-12 h-12 rounded-lg" />
                                <Skeleton className="w-32 h-6 rounded-full" />
                            </div>
                            <div className="flex flex-col md:flex-row gap-6">
                                <div className="flex-1 space-y-4">
                                    <Skeleton className="w-full h-10 rounded-lg mb-8" />
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {[1, 2, 3, 4].map((opt) => (
                                            <Skeleton key={opt} className="w-full h-14 rounded-xl" />
                                        ))}
                                    </div>
                                </div>
                                <div className="w-full md:w-48 shrink-0">
                                    <Skeleton className="w-full h-32 rounded-lg" />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </motion.div>
        );
    }

    const answeredCount = Object.keys(answers).length;
    const totalCount = questions.length;
    const progressPercent = totalCount > 0 ? (answeredCount / totalCount) * 100 : 0;

    return (
        <div className="w-full min-h-screen bg-[var(--bg-app)] text-zinc-900 dark:text-[#fafafa] pb-28" dir="rtl">
            <header className="fixed top-0 z-50 w-full bg-[var(--bg-app)]/90 backdrop-blur-xl border-b border-black/10 dark:border-white/10 h-16 md:h-20">
                <div className="max-w-7xl mx-auto flex w-full px-4 h-full items-center justify-between">
                    <div className="hidden md:flex items-center gap-1.5 shrink-0 overflow-x-auto scrollbar-hide flex-nowrap max-w-[50vw]">
                        <FilterGroup
                            prefix="desktop"
                            activeFilter={activeFilter}
                            setActiveFilter={setActiveFilter}
                            subjects={subjects}
                        />
                    </div>

                    <div className="flex md:hidden items-center gap-3">
                        <QuestionCounter current={answeredCount} total={totalCount} />
                        <div className="w-px h-4 bg-black/10 dark:bg-white/10" />
                        {remainingSeconds > 0 && (
                            <CountdownTimer key={`mobile-${remainingSeconds}`} initialSeconds={remainingSeconds} onTimeUp={handleTimeUp} />
                        )}
                    </div>

                    <div className="flex items-center gap-2 md:gap-4 shrink-0">
                        <div className="hidden md:flex items-center gap-4">
                            <div className="w-px h-5 bg-black/10 dark:bg-white/10" />
                            <QuestionCounter current={answeredCount} total={totalCount} />
                            <div className="w-px h-5 bg-black/10 dark:bg-white/10" />
                            {remainingSeconds > 0 && (
                                <CountdownTimer key={`desktop-${remainingSeconds}`} initialSeconds={remainingSeconds} onTimeUp={handleTimeUp} />
                            )}
                            <div className="w-px h-5 bg-black/10 dark:bg-white/10" />
                        </div>

                        <button onClick={() => setIsModalOpen(true)} disabled={isSubmitting} className="group flex items-center gap-1 md:gap-2 text-xs md:text-sm font-bold text-[var(--accent)] border-2 border-[var(--accent)] px-4 py-1.5 rounded-full hover:bg-[var(--accent)] hover:text-white transition-all shrink-0 disabled:opacity-60 disabled:cursor-not-allowed">
                            <span>{isSubmitting ? 'در حال ثبت...' : 'پایان'}</span>
                            {isSubmitting ? (
                                <Loader2 size={16} className="animate-spin" strokeWidth={2.5} />
                            ) : (
                                <ChevronLeft size={16} className="transition-transform group-hover:-translate-x-1" strokeWidth={2.5} />
                            )}
                        </button>
                    </div>
                </div>
                <motion.div initial={{ width: 0 }} animate={{ width: `${progressPercent}%` }} transition={{ duration: 0.5, ease: butteryEase }} className="absolute bottom-0 left-0 h-[2px] bg-[var(--accent)] z-50" />
            </header>

            <div className="md:hidden sticky top-16 mb-10 left-0 right-0 z-40 bg-[var(--bg-app)]/95 backdrop-blur-xl border-b border-black/5 dark:border-white/5">
                <div className="overflow-x-auto scrollbar-hide px-4 py-3">
                    <div className="flex justify-center min-w-max mx-auto gap-2 whitespace-nowrap">
                        <FilterGroup
                            prefix="mobile"
                            activeFilter={activeFilter}
                            setActiveFilter={setActiveFilter}
                            subjects={subjects}
                        />
                    </div>
                </div>
            </div>

            <main className="max-w-7xl mx-auto px-4 pt-15 md:pt-12 lg:pt-25 pb-25">
                {/* Minimal Real-time Progress Section (only when in Lobby Mode) */}
                {isLobbyMode && avatarDataList.length > 0 && (
                    <div className="mb-10 w-full">
                        <AvatarList avatars={avatarDataList} />
                    </div>
                )}

                {!isPrivatePreviewRef.current && socketStatus === 'connecting' && (
                    <div className="mb-6 rounded-2xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 px-4 py-3 text-amber-700 dark:text-amber-300 text-sm font-bold">
                        در حال اتصال به لابی...
                    </div>
                )}
                {visibleError && questions.length > 0 && (
                    <div className="mb-6 rounded-2xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-4 py-3 text-rose-600 dark:text-rose-300 text-sm font-bold">
                        {visibleError}
                    </div>
                )}

                <AnimatePresence mode="popLayout">
                    {filteredQuestions.map((q, index) => {
                        return (
                            <motion.section
                                layout
                                key={q.id}
                                ref={(el) => (questionRefs.current[q.id] = el)}
                                data-question-id={q.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -10 }}
                                transition={{ duration: 0.4, ease: butteryEase }}
                                className="w-full relative"
                            >
                                <div className="flex flex-col md:flex-row gap-6 w-full">
                                    <div className="flex-1 space-y-6 w-full">

                                        {/* Inline Modern Title Row - Expanded to fill the width */}
                                        <div className="flex items-start w-full">
                                            <div className="text-lg md:text-xl flex font-bold leading-relaxed text-zinc-900 dark:text-zinc-100 w-full">
                                                <div className="text-3xl md:text-4xl font-black text-[var(--accent)] tabular-nums leading-none tracking-tighter shrink-0 select-none ml-2">
                                                    {String(index + 1).padStart(2, '0')}
                                                </div>
                                                <div className="mt-1 flex-1 w-full min-w-0">
                                                    <MathRenderer text={decodeHtmlEntities(q.text)} subject={q.subject_id} />
                                                </div>
                                            </div>
                                        </div>

                                        {q.has_image && q.image_url && (
                                            <div className="w-full md:w-48 shrink-0 flex justify-center md:justify-start">
                                                <img src={`${baseImageUrl}${q.image_url}`} alt="تصویر" className="max-w-[200px] w-full rounded-lg object-contain border border-zinc-200 dark:border-zinc-800" />
                                            </div>
                                        )}
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                                            {q.options?.map((opt) => {
                                                const isSelected = answers[q.id] === opt.id;
                                                return (
                                                    <button key={opt.id} onClick={() => handleSelectAnswer(q.id, opt.id)} disabled={isSubmitting} className={`relative flex items-center w-full p-4 rounded-xl text-right transition-all border disabled:opacity-70 disabled:cursor-not-allowed ${isSelected ? 'border-[var(--accent)] bg-[var(--accent)]/5' : 'border-zinc-200 dark:border-white/10 hover:bg-zinc-50 dark:hover:bg-white/5'}`}>
                                                        <div className="relative z-10 flex items-center gap-4 w-full">
                                                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ${isSelected ? 'border-[var(--accent)] bg-[var(--accent)]' : 'border-zinc-400 dark:border-zinc-500'}`}>
                                                                <AnimatePresence>
                                                                    {isSelected && (
                                                                        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                                                                            <Check size={12} className="text-white" strokeWidth={4} />
                                                                        </motion.div>
                                                                    )}
                                                                </AnimatePresence>
                                                            </div>
                                                            <div className={`text-sm md:text-base flex-1 transition-colors ${isSelected ? 'text-[var(--accent)] font-bold' : 'text-zinc-700 dark:text-zinc-300 font-medium'}`}>
                                                                <MathRenderer text={decodeHtmlEntities(opt.text)} subject={q.subject_id} />
                                                            </div>
                                                        </div>
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </div>
                                <hr className="border-zinc-200 dark:border-zinc-800 my-12" />
                            </motion.section>
                        );
                    })}
                </AnimatePresence>
            </main>

            <ResponsiveModal isOpen={isModalOpen} onClose={() => { if (!isSubmitting) setIsModalOpen(false); }} title="پایان آزمون">
                <div className="flex flex-col items-center text-center space-y-4 py-4">
                    <div className="w-16 h-16 rounded-full bg-[var(--accent)]/10 flex items-center justify-center text-[var(--accent)] mb-2">
                        <AlertCircle size={32} />
                    </div>
                    <p className="text-zinc-800 dark:text-zinc-200 text-sm md:text-base font-bold">آیا از پایان دادن به این آزمون اطمینان دارید؟</p>
                    {visibleError && (
                        <p className="text-rose-500 text-sm font-bold">{visibleError}</p>
                    )}
                    <div className="flex w-full gap-3 pt-6">
                        <button onClick={confirmFinish} disabled={isSubmitting} className="flex-1 py-3 px-4 rounded-xl bg-[var(--accent)] text-white text-sm font-bold hover:bg-[var(--accent)]/90 transition-colors disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                            {isSubmitting ? <><Loader2 size={18} className="animate-spin" /><span>در حال ثبت...</span></> : 'بله، ثبت و مشاهده نتیجه'}
                        </button>
                        <button onClick={() => setIsModalOpen(false)} disabled={isSubmitting} className="flex-1 py-3 px-4 rounded-xl border-2 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 text-sm font-bold hover:bg-zinc-100 dark:hover:bg-white/5 transition-colors disabled:opacity-60 disabled:cursor-not-allowed">خیر، ادامه می‌دهم</button>
                    </div>
                </div>
            </ResponsiveModal>
        </div>
    );
}