//quizWorldController
const pool = require('../db');
const crypto = require('crypto');
const {
    encodeQuizId,
    decodeQuizId,
    encodeShareCode,
    decodeShareCode,
    encodeResultId,
    decodeResultId
} = require('../utils/hash');
const {
    ensureQuestionTagTables,
    joinOnTag,
    matchTagIn,
    addTagFilter,
    toPositiveIds,
    majorityGradeSql,
    playableQuestionSql,
    filterTopicsForSelectedGrades,
    annotateTopicGrade,
} = require('../utils/questionTags');
const entitlements = require('../subscription/entitlements');
const usage = require('../subscription/usage');
const { ensureVisitorCountIds } = require('../visitorCounts');


// ==========================================
// CONFIGURATION
// ==========================================
const MIN_QUESTIONS = 1;

const isPresent = (val) => {
    if (val === undefined || val === null || val === '' || val === 'null' || val === 'undefined') return false;
    if (Array.isArray(val) && val.length === 0) return false;
    return true;
};

const pickBodyValue = (body, keys) => {
    for (const key of keys) {
        if (isPresent(body?.[key])) return body[key];
    }
    return undefined;
};

const toPositiveInt = (n) => {
    const num = Number(n);
    return Number.isInteger(num) && num > 0 ? num : null;
};

// Helper to ensure we always get an array of IDs from the request
const parseArrayParam = (val) => {
    if (!isPresent(val)) return [];
    if (Array.isArray(val)) {
        // String([]) === '' so empty arrays must be handled before any String() check
        return val.flatMap((item) => {
            if (item && typeof item === 'object' && item.id != null) {
                return parseArrayParam(item.id);
            }
            const num = toPositiveInt(item);
            return num == null ? [] : [num];
        });
    }
    if (typeof val === 'object' && val.id != null) {
        return parseArrayParam(val.id);
    }
    if (typeof val === 'string') {
        const trimmed = val.trim();
        if (!trimmed || trimmed === '[]') return [];
        try {
            const parsed = JSON.parse(trimmed);
            if (parsed !== trimmed) return parseArrayParam(parsed);
        } catch (e) {
            // comma-separated "1,2,3"
        }
        return trimmed.split(',').map((v) => toPositiveInt(v.trim())).filter((n) => n != null);
    }
    const num = toPositiveInt(val);
    return num == null ? [] : [num];
};

const addInFilter = (parts, params, column, ids) => {
    if (!ids.length) return;
    parts.push(`${column} IN (${ids.map(() => '?').join(',')})`);
    params.push(...ids);
};

function getDifficultyDistribution(level, total) {
    const numericLevel = Number(level);

    let ratios;
    if (numericLevel === 1) {
        // Easy quiz: 80% easy, 20% normal
        ratios = {
            'آسان': 0.8,
            'متوسط': 0.2,
            'سخت': 0
        };
    } else if (numericLevel === 2) {
        // Normal quiz: 20% easy, 70% normal, 10% hard
        ratios = {
            'آسان': 0.2,
            'متوسط': 0.7,
            'سخت': 0.1
        };
    } else if (numericLevel === 3) {
        // Hard quiz: 15% easy, 25% normal, 60% hard
        ratios = {
            'آسان': 0.15,
            'متوسط': 0.25,
            'سخت': 0.6
        };
    } else {
        // Fallback: normal
        ratios = {
            'آسان': 0.2,
            'متوسط': 0.7,
            'سخت': 0.1
        };
    }

    const levels = ['آسان', 'متوسط', 'سخت'];
    const counts = {};
    let assigned = 0;

    for (let i = 0; i < levels.length; i++) {
        const diff = levels[i];
        if (i < levels.length - 1) {
            counts[diff] = Math.floor(total * ratios[diff]);
            assigned += counts[diff];
        } else {
            counts[diff] = total - assigned;
        }
    }

    return counts;
}

function shuffleArray(arr) {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}

async function fetchQuestionIdsByDifficulty({
                                                pool,
                                                lessons,
                                                grades,
                                                targetColumn,
                                                itemId,
                                                limit,
                                                difficultySetting
                                            }) {
    await ensureQuestionTagTables();
    const distribution = getDifficultyDistribution(difficultySetting, limit);

    const selectedIds = [];
    const selectedSet = new Set();

    const gradeMatch = matchTagIn('q', 'grade', grades);
    const itemMatch = targetColumn === 'topic_id'
        ? matchTagIn('q', 'topic', [itemId])
        : matchTagIn('q', 'mabhas', [itemId]);
    const subjectPlaceholders = lessons.map(() => '?').join(',');

    const baseWhere = `
        FROM questions_tam24 q
        WHERE ${playableQuestionSql('q')}
          AND q.subject_id IN (${subjectPlaceholders})
          ${gradeMatch.sql ? `AND ${gradeMatch.sql}` : ''}
          ${itemMatch.sql ? `AND ${itemMatch.sql}` : ''}
    `;
    const baseParams = [...lessons, ...gradeMatch.params, ...itemMatch.params];

    async function fetchBucket(difficultyLevel, bucketLimit) {
        if (bucketLimit <= 0) return [];

        const sql = `
            SELECT q.id
            ${baseWhere}
              AND q.difficulty_level = ?
            ORDER BY RAND()
            LIMIT ?
        `;

        const [rows] = await pool.query(sql, [
            ...baseParams,
            difficultyLevel,
            bucketLimit
        ]);

        return rows.map(row => row.id);
    }

    async function fetchFallback(excludeIds, needed) {
        if (needed <= 0) return [];

        let sql = `
            SELECT q.id
            ${baseWhere}
        `;

        const params = [...baseParams];

        if (excludeIds.length > 0) {
            sql += ` AND q.id NOT IN (${excludeIds.map(() => '?').join(',')}) `;
            params.push(...excludeIds);
        }

        sql += `
            ORDER BY RAND()
            LIMIT ?
        `;
        params.push(needed);

        const [rows] = await pool.query(sql, params);
        return rows.map(row => row.id);
    }

    const difficultyOrder = ['آسان', 'متوسط', 'سخت'];

    // First pass: fetch based on target distribution
    for (const difficultyLevel of difficultyOrder) {
        const bucketLimit = distribution[difficultyLevel];
        const ids = await fetchBucket(difficultyLevel, bucketLimit);

        for (const id of ids) {
            if (!selectedSet.has(id)) {
                selectedSet.add(id);
                selectedIds.push(id);
            }
        }
    }

    // Second pass: if some difficulty bucket had fewer questions than needed,
    // fill from any available difficulty in same filters
    const shortage = limit - selectedIds.length;
    if (shortage > 0) {
        const fallbackIds = await fetchFallback(selectedIds, shortage);

        for (const id of fallbackIds) {
            if (!selectedSet.has(id)) {
                selectedSet.add(id);
                selectedIds.push(id);
            }
        }
    }

    return shuffleArray(selectedIds);
}




const generateCode = async (req, res) => {
    try {
        // FIXED: Multiply by 900000 instead of 999999
        const numericCode = Math.floor(100000 + Math.random() * 900000);
        const hashedCode = encodeShareCode(numericCode);

        return res.json({
            success: true,
            data: {
                code: hashedCode,
            },
        });
    } catch (error) {
        return res.json({
            success: false,
            message: 'Error in code generation',
        });
    }
};




const handleGetSubjects = async (req, res) => {
    try {
        await ensureQuestionTagTables();
        const sql = `
            SELECT s.id, s.title, s.icon , COUNT(q.id) AS question_count
            FROM questions_tam24 q
            JOIN subjects_tam24 s ON q.subject_id = s.id
            WHERE ${playableQuestionSql('q')}
            GROUP BY s.id, s.title, s.icon
            HAVING COUNT(q.id) >= ?
            ORDER BY s.id ASC
        `;
        const [rows] = await pool.query(sql, [MIN_QUESTIONS]);
        res.json({ success: true, subjects: rows });
    } catch (error) {
        console.error("❌ SQL Error in handleGetSubjects:", error);
        res.json({ success: false, message: "Database error fetching subjects" });
    }
};

const handleGetGradesBySubjects = async (req, res) => {
    try {
        await ensureQuestionTagTables();
        const subjectIds = parseArrayParam(pickBodyValue(req.body, ['subject_ids', 'subjects', 'lessons']));
        if (subjectIds.length === 0) {
            return res.json({ success: false, message: "Missing or invalid parameter: subject_ids array" });
        }

        const sql = `
            SELECT g.id, g.title, COUNT(DISTINCT q.id) AS question_count
            FROM questions_tam24 q
            INNER JOIN grades_tam24 g ON ${joinOnTag('q', 'g', 'grade')}
            WHERE q.subject_id IN (?)
               AND ${playableQuestionSql('q')}
            GROUP BY g.id, g.title
            HAVING COUNT(DISTINCT q.id) >= ?
            ORDER BY g.id ASC
        `;
        const [rows] = await pool.query(sql, [subjectIds, MIN_QUESTIONS]);
        res.json({ success: true, grades: rows });
    } catch (error) {
        console.error("❌ SQL Error in handleGetGradesBySubjects:", error);
        res.json({ success: false, message: "Database error fetching grades" });
    }
};

const handleGetChaptersBySubjects = async (req, res) => {
    try {
        await ensureQuestionTagTables();
        const subjectIds = parseArrayParam(pickBodyValue(req.body, ['subject_ids', 'subjects', 'lessons']));
        if (subjectIds.length === 0) {
            return res.json({ success: false, message: "Missing or invalid parameter: subject_ids array" });
        }

        const gradeIds = parseArrayParam(pickBodyValue(req.body, ['grade_ids', 'grades']));
        const gradeMatch = matchTagIn('q', 'grade', gradeIds);

        let sql = `
            SELECT t.id, t.title, COUNT(DISTINCT q.id) AS question_count, t.subject_id,
                   MIN(q.grade_id) AS grade_id,
                   ${majorityGradeSql('t', { requireEditDone: true })} AS majority_grade_id
            FROM questions_tam24 q
            JOIN topics_tam24 t ON ${joinOnTag('q', 't', 'topic')}
            WHERE q.subject_id IN (?)
               AND ${playableQuestionSql('q')}
        `;
        const params = [subjectIds];
        if (gradeMatch.sql) {
            sql += ` AND ${gradeMatch.sql}`;
            params.push(...gradeMatch.params);
        }

        sql += `
            GROUP BY t.id, t.title, t.subject_id
            HAVING COUNT(DISTINCT q.id) >= ?
            ORDER BY t.subject_id ASC, t.id ASC
        `;
        params.push(MIN_QUESTIONS);
        const [rows] = await pool.query(sql, params);
        res.json({
            success: true,
            chapters: filterTopicsForSelectedGrades(rows, gradeIds).map(annotateTopicGrade),
        });
    } catch (error) {
        console.error("❌ SQL Error in handleGetChaptersBySubjects:", error);
        res.json({ success: false, message: "Database error fetching chapters" });
    }
};

const handleGetMabahesByChapters = async (req, res) => {
    try {
        await ensureQuestionTagTables();
        const topicIds = toPositiveIds(parseArrayParam(pickBodyValue(req.body, ['topic_ids', 'chapters'])));
        if (topicIds.length === 0) {
            return res.json({ success: false, message: "Missing or invalid parameter: topic_ids array" });
        }

        const gradeIds = parseArrayParam(pickBodyValue(req.body, ['grade_ids', 'grades']));
        const topicMatch = matchTagIn('q', 'topic', topicIds);
        const gradeMatch = matchTagIn('q', 'grade', gradeIds);

        const topicPlaceholders = topicIds.map(() => '?').join(',');
        let sql = `
            SELECT c.id, c.title, COUNT(DISTINCT q.id) AS question_count,
                   MIN(q.topic_id) AS chapter_id, MIN(q.grade_id) AS grade_id, MIN(q.subject_id) AS subject_id
            FROM questions_tam24 q
            JOIN chapters_tam24 c ON ${joinOnTag('q', 'c', 'mabhas')}
            WHERE ${playableQuestionSql('q')}
               AND ${topicMatch.sql || '1=1'}
               AND c.topic_id IN (${topicPlaceholders})
        `;
        const params = [...topicMatch.params, ...topicIds];
        if (gradeMatch.sql) {
            sql += ` AND ${gradeMatch.sql}`;
            params.push(...gradeMatch.params);
        }
        sql += `
            GROUP BY c.id, c.title
            HAVING COUNT(DISTINCT q.id) >= ?
            ORDER BY MIN(q.topic_id) ASC, c.id ASC
        `;
        params.push(MIN_QUESTIONS);
        const [rows] = await pool.query(sql, params);
        res.json({ success: true, mabahes: rows });
    } catch (error) {
        console.error("❌ SQL Error in handleGetMabahesByChapters:", error);
        res.json({ success: false, message: "Database error fetching mabahes" });
    }
};

const buildQuestionFiltersMultiple = (body) => {
    const filters = [];
    const params = [];

    const mapping = {
        grade_ids:        'q.grade_id',
        subject_ids:      'q.subject_id',
        topic_ids:        'q.topic_id',
        chapter_ids:      'q.chapter_id',
    };

    // Array logic
    for (const [postKey, column] of Object.entries(mapping)) {
        const arr = parseArrayParam(body[postKey] || body[postKey.replace('_ids', 's')]);
        if (arr.length > 0) {
            filters.push(`${column} IN (?)`);
            params.push(arr);
        }
    }

    // Single value logic for others like academic_year, difficulty_level
    const singleMapping = {
        academic_year:   'q.academic_year',
        difficulty_level:'q.difficulty_level',
    };

    for (const [postKey, column] of Object.entries(singleMapping)) {
        const value = body[postKey];
        if (value !== undefined && value !== null && value !== 'null' && value !== 'undefined' && String(value).trim() !== '') {
            filters.push(`${column} = ?`);
            params.push(value);
        }
    }

    return { filters, params };
};

const generateShareCode = () => {
    return crypto.randomBytes(3).toString('hex').toUpperCase(); // e.g., 'A1B2C3'
};


const fetchQuestionOptions = async (questionId) => {
    const [rows] = await pool.query(
        "SELECT id, option_text FROM options_tam24 WHERE question_id = ? ORDER BY id ASC",
        [questionId]
    );
    return rows.map(opt => ({ id: Number(opt.id), text: opt.option_text }));
};

async function attachQuestionImages(connection, questionIds, questionDetailsMap) {
    if (!questionIds.length) return;
    const placeholders = questionIds.map(() => '?').join(',');
    const [rows] = await connection.query(
        `SELECT question_id, image_name FROM question_images_tam24 WHERE question_id IN (${placeholders}) ORDER BY id ASC`,
        questionIds
    );
    for (const row of rows) {
        const bucket = questionDetailsMap[row.question_id];
        if (!bucket) continue;
        if (!bucket.images) bucket.images = [];
        bucket.images.push(row.image_name);
    }
}

const fetchQuestionImages = async (questionId) => {
    const [rows] = await pool.query(
        "SELECT image_name FROM question_images_tam24 WHERE question_id = ? ORDER BY id ASC",
        [questionId]
    );
    return rows.map(img => img.image_name);
};

const handleSearchBankQuestions = async (req, res) => {
    try {
        const body = req.body || {};
        const subjectIds = parseArrayParam(pickBodyValue(body, ['subject_ids', 'subjects', 'lessons']));
        const gradeIds = parseArrayParam(pickBodyValue(body, ['grade_ids', 'grades']));
        const topicIds = parseArrayParam(pickBodyValue(body, ['topic_ids', 'chapters']));
        const chapterIds = parseArrayParam(pickBodyValue(body, ['chapter_ids', 'mabhas']));
        const difficultyList = (Array.isArray(body.difficulties) ? body.difficulties : [])
            .map((d) => String(d).trim())
            .filter((d) => ['آسان', 'متوسط', 'سخت'].includes(d));
        const search = typeof body.search === 'string' ? body.search.trim() : '';
        const includeOptions = Boolean(body.includeOptions);
        const sample = Boolean(body.sample);
        const page = Math.max(1, parseInt(body.page, 10) || 1);
        const pageSize = Math.min(40, Math.max(5, parseInt(body.pageSize, 10) || 12));
        const sampleSize = Math.min(300, Math.max(1, parseInt(body.sampleSize, 10) || 10));

        const runFilteredCount = async (requireEditDone) => {
            await ensureQuestionTagTables();
            const parts = [requireEditDone ? playableQuestionSql('q') : "q.status = 'فعال'"];
            const params = [];
            addInFilter(parts, params, 'q.subject_id', subjectIds);
            addTagFilter(parts, params, 'q', 'grade', gradeIds);
            addTagFilter(parts, params, 'q', 'topic', topicIds);
            addTagFilter(parts, params, 'q', 'mabhas', chapterIds);
            addInFilter(parts, params, 'q.difficulty_level', difficultyList);
            if (search) {
                parts.push('q.question_text LIKE ?');
                params.push(`%${search}%`);
            }
            const whereSql = parts.join(' AND ');
            const [[{ total }]] = await pool.query(
                `SELECT COUNT(*) AS total FROM questions_tam24 q WHERE ${whereSql}`,
                params
            );
            return { total: Number(total) || 0, whereSql, params };
        };

        // Same pool as the wizard, including every زیست یازدهم question.
        // If that pool is empty, fall back to any فعال row.
        let filtered = await runFilteredCount(true);
        let usedEditDone = true;
        if (filtered.total === 0) {
            const relaxed = await runFilteredCount(false);
            if (relaxed.total > 0) {
                filtered = relaxed;
                usedEditDone = false;
            }
        }

        const limit = sample ? sampleSize : pageSize;
        const offset = sample ? 0 : (page - 1) * pageSize;
        const orderSql = sample ? 'ORDER BY RAND()' : 'ORDER BY q.id DESC';
        const safeLimit = Number.parseInt(limit, 10) || 12;
        const safeOffset = Math.max(0, Number.parseInt(offset, 10) || 0);

        const listSql = `
            SELECT q.id, q.question_text, q.difficulty_level, q.subject_id, q.grade_id, q.topic_id, q.chapter_id,
                   s.title AS subject_title, g.title AS grade_title, t.title AS topic_title, c.title AS chapter_title
            FROM questions_tam24 q
            LEFT JOIN subjects_tam24 s ON q.subject_id = s.id
            LEFT JOIN grades_tam24 g ON q.grade_id = g.id
            LEFT JOIN topics_tam24 t ON q.topic_id = t.id
            LEFT JOIN chapters_tam24 c ON q.chapter_id = c.id
            WHERE ${filtered.whereSql}
            ${orderSql}
            LIMIT ${safeLimit} OFFSET ${safeOffset}
        `;
        const [rows] = await pool.query(listSql, filtered.params);

        let optionsByQuestion = {};
        if (includeOptions && rows.length > 0) {
            const ids = rows.map((r) => Number(r.id)).filter((n) => n > 0);
            if (ids.length) {
                const [optRows] = await pool.query(
                    `SELECT id, question_id, option_text FROM options_tam24 WHERE question_id IN (${ids.map(() => '?').join(',')}) ORDER BY id ASC`,
                    ids
                );
                for (const opt of optRows) {
                    if (!optionsByQuestion[opt.question_id]) optionsByQuestion[opt.question_id] = [];
                    optionsByQuestion[opt.question_id].push({ id: Number(opt.id), text: opt.option_text });
                }
            }
        }

        let imagesByQuestion = {};
        if (rows.length > 0) {
            const ids = rows.map((r) => Number(r.id)).filter((n) => n > 0);
            if (ids.length) {
                const [imgRows] = await pool.query(
                    `SELECT question_id, image_name FROM question_images_tam24 WHERE question_id IN (${ids.map(() => '?').join(',')}) ORDER BY id ASC`,
                    ids
                );
                for (const img of imgRows) {
                    if (!imagesByQuestion[img.question_id]) imagesByQuestion[img.question_id] = img.image_name;
                }
            }
        }

        const questions = rows.map((q) => ({
            id: Number(q.id),
            text: q.question_text,
            difficulty: q.difficulty_level || 'متوسط',
            subject_id: q.subject_id,
            grade_id: q.grade_id,
            topic_id: q.topic_id,
            chapter_id: q.chapter_id,
            subject_title: q.subject_title || '',
            grade_title: q.grade_title || '',
            topic_title: q.topic_title || '',
            chapter_title: q.chapter_title || '',
            image: imagesByQuestion[q.id] || null,
            options: optionsByQuestion[q.id] || [],
        }));

        res.json({
            success: true,
            questions,
            pagination: {
                total: filtered.total,
                page: sample ? 1 : page,
                pageSize: safeLimit,
                sample,
                editStatusFilter: usedEditDone ? 'done' : 'any',
            },
        });
    } catch (error) {
        console.error('❌ SQL Error in handleSearchBankQuestions:', error);
        res.json({ success: false, message: 'خطا در دریافت سوالات بانک' });
    }
};

const parseIsCorrectFlag = (val) => {
    if (Buffer.isBuffer(val)) return val[0] === 1;
    return Number(val) === 1 || val === true || val === '1';
};

const handleGetBankQuestionAnswer = async (req, res) => {
    try {
        const questionId = toPositiveInt(req.body?.question_id ?? req.body?.questionId);
        if (!questionId) {
            return res.json({ success: false, message: 'شناسه سوال نامعتبر است.' });
        }

        const [optRows] = await pool.query(
            `SELECT id, option_text, COALESCE(CAST(is_correct AS UNSIGNED), 0) AS is_correct
             FROM options_tam24
             WHERE question_id = ?
             ORDER BY id ASC`,
            [questionId]
        );
        const [descRows] = await pool.query(
            'SELECT answer_text FROM descriptive_answers_tam24 WHERE question_id = ? LIMIT 1',
            [questionId]
        );

        const options = optRows.map((row) => ({
            id: Number(row.id),
            text: row.option_text,
            is_correct: parseIsCorrectFlag(row.is_correct),
        }));
        const correct = options.find((opt) => opt.is_correct);

        res.json({
            success: true,
            question_id: questionId,
            options,
            correct_option_id: correct ? correct.id : null,
            descriptive_answer: descRows.length > 0 ? descRows[0].answer_text : null,
        });
    } catch (error) {
        console.error('❌ SQL Error in handleGetBankQuestionAnswer:', error);
        res.json({ success: false, message: 'خطا در دریافت پاسخ سوال' });
    }
};

const handleCreateQuiz = async (req, res) => {
    const creatorId = req.user?.id || 1;
    let examClaim = null;

    const {
        quizType, // 'chapter' or 'mabhas' or 'selector'
        settings,
        lessonNames,
        gradeNames,
        chapterNames,
        mabhasNames
    } = req.body;

    const lessons = parseArrayParam(req.body.lessons);
    const grades = parseArrayParam(req.body.grades);
    const chapters = parseArrayParam(req.body.chapters);
    const mabhas = parseArrayParam(req.body.mabhas);
    const explicitQuestionIds = parseArrayParam(req.body.question_ids || req.body.questionIds);
    const shareCode = decodeShareCode(req.body.shareCode);
    const isSelectorQuiz = quizType === 'selector' || explicitQuestionIds.length > 0;

    if (!settings || (!isSelectorQuiz && (!quizType || !settings.questionCounts))) {
        return res.json({ success: false, message: "اطلاعات ارسالی ناقص است." });
    }

    let allSelectedQuestionIds = [];
    const questionCounts = settings.questionCounts || {};
    const targetItems = quizType === 'chapter' ? chapters : mabhas;
    const targetColumn = quizType === 'chapter' ? 'topic_id' : 'chapter_id';

    if (!isSelectorQuiz && (lessons.length === 0 || grades.length === 0)) {
        return res.json({ success: false, message: "پایه یا درس انتخاب نشده است." });
    }

    try {
        if (isSelectorQuiz) {
            const uniqueIds = [...new Set(explicitQuestionIds)].slice(0, 50);
            if (uniqueIds.length === 0) {
                return res.json({ success: false, message: "هیچ سوالی انتخاب نشده است." });
            }
            await ensureQuestionTagTables();
            const [foundRows] = await pool.query(
                `SELECT id FROM questions_tam24 q
                 WHERE q.id IN (${uniqueIds.map(() => '?').join(',')}) AND ${playableQuestionSql('q')}`,
                uniqueIds
            );
            const found = new Set(foundRows.map((r) => Number(r.id)));
            allSelectedQuestionIds = uniqueIds.filter((id) => found.has(id));
        } else {
        for (const itemId of targetItems) {
            const limit = parseInt(questionCounts[itemId]) || 0;
            if (limit <= 0) continue;

            const fetchedIds = await fetchQuestionIdsByDifficulty({
                pool,
                lessons,
                grades,
                targetColumn,
                itemId,
                limit,
                difficultySetting: settings.difficulty
            });

            allSelectedQuestionIds.push(...fetchedIds);
        }
        }

        if (allSelectedQuestionIds.length === 0) {
            return res.json({ success: false, message: "هیچ سوالی با این مشخصات یافت نشد." });
        }

        if (!isSelectorQuiz) {
            allSelectedQuestionIds = allSelectedQuestionIds.sort(() => Math.random() - 0.5);
        }

        const title =
            settings.quizName && settings.quizName.trim() !== ''
                ? settings.quizName
                : 'آزمون سفارشی';

        const enrichedSettings = {
            ...settings,
            selectionNames: {
                lessonNames: lessonNames || {},
                gradeNames: gradeNames || {},
                chapterNames: chapterNames || {},
                mabhasNames: mabhasNames || {}
            }
        };

        /**
         * If quiz is private, it should start immediately.
         * Public quizzes can stay pending/waiting until lobby starts.
         */
        const quizStatus = settings.visibility === 'private'
            ? 'in_progress'
            : 'waiting';

        examClaim = await entitlements.prepareExamCreate(creatorId, settings.visibility);
        if (!examClaim.ok) {
            return res.json({
                success: false,
                code: examClaim.code,
                message: examClaim.message,
                nextAllowedAt: examClaim.nextAllowedAt || null,
            });
        }

        const insertQuizSql = `
            INSERT INTO quizzes 
            (
                share_code,
                creator_id,
                title,
                quiz_type,
                difficulty,
                time_limit,
                visibility,
                member_limit,
                status,
                question_ids,
                settings
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [quizResult] = await pool.query(insertQuizSql, [
            shareCode,
            creatorId,
            title,
            isSelectorQuiz ? 'selector' : quizType,
            Number(settings.difficulty) || 2,
            Number(settings.time) || 30,
            settings.visibility === 'public' ? 'public' : 'private',
            Number(settings.memberLimit) || 10,
            quizStatus,
            JSON.stringify(allSelectedQuestionIds),
            JSON.stringify(enrichedSettings)
        ]);

        const newQuizId = quizResult.insertId;

        if (examClaim?.usageId) {
            await usage.bindResource(examClaim.usageId, newQuizId);
            examClaim = null;
        }


        return res.json({
            success: true,
            quiz: {
                id: encodeQuizId(newQuizId),
                shareCode: encodeShareCode(shareCode),
                title: title,
                totalQuestions: allSelectedQuestionIds.length,
                timeLimit: settings.time,
                visibility: settings.visibility,
                status: quizStatus
            }
        });

    } catch (error) {
        if (examClaim?.usageId) await usage.releaseUsage(examClaim.usageId);
        console.error("❌ SQL Error in handleCreateQuiz:", error);
        return res.json({ success: false, message: "خطا در ساخت آزمون در پایگاه داده" });
    }
};


const handleAddQuizMember = async (req, res) => {
    /**
     * quizId can come from params.
     * Example:
     * POST /internal/quizzes/:quizId/members
     */
    const incomingQuizId = req.params.quizId || req.body.quizId;

    const {
        userId,
        role
    } = req.body;

    if (!incomingQuizId || !userId || !role) {
        return res.status(400).json({
            success: false,
            message: "اطلاعات ارسالی ناقص است."
        });
    }

    if (!['creator', 'member'].includes(role)) {
        return res.status(400).json({
            success: false,
            message: "نقش کاربر معتبر نیست."
        });
    }

    /**
     * If quiz id comes encoded/hash from socket service,
     * decode it before inserting into DB.
     *
     * If your internal endpoint receives raw numeric id,
     * you can replace this with:
     *
     * const quizId = Number(incomingQuizId);
     */
    let quizId;

    try {
        quizId = decodeQuizId(incomingQuizId);
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: "شناسه آزمون معتبر نیست."
        });
    }

    if (!quizId || Number.isNaN(Number(quizId))) {
        return res.status(400).json({
            success: false,
            message: "شناسه آزمون معتبر نیست."
        });
    }

    if (role === 'member' && await entitlements.multiplayerBlocked(userId)) {
        const conn = await pool.getConnection();
        try {
            const [rows] = await conn.query(
                `SELECT visibility FROM quizzes WHERE id = ? LIMIT 1`,
                [quizId]
            );
            if (rows[0]?.visibility === 'public') {
                return res.status(403).json({
                    success: false,
                    code: 'MULTIPLAYER_LOCKED',
                    message: 'ورود به آزمون آنلاین با اشتراک ویژه ممکن است.',
                });
            }
        } finally {
            conn.release();
        }
    }

    try {
        /**
         * Optional: make sure quiz exists.
         */
        const [quizRows] = await pool.query(
            `
            SELECT id, creator_id
            FROM quizzes
            WHERE id = ?
            LIMIT 1
            `,
            [quizId]
        );

        if (quizRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "آزمون یافت نشد."
            });
        }

        const quiz = quizRows[0];

        /**
         * If requested role is member but this user is actually the quiz creator,
         * treat them as creator.
         */
        const finalRole =
            Number(quiz.creator_id) === Number(userId)
                ? 'creator'
                : role;

        /**
         * Insert member if not exists.
         *
         * Important:
         * - If the row already exists as creator, keep creator.
         * - If the row already exists as member and now role is creator, upgrade to creator.
         * - If the row already exists as creator and now role is member, do not downgrade.
         */
        const insertMemberSql = `
            INSERT INTO quiz_members
            (
                quiz_id,
                user_id,
                role
            )
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                role = CASE
                    WHEN role = 'creator' THEN 'creator'
                    WHEN VALUES(role) = 'creator' THEN 'creator'
                    ELSE role
                END
        `;

        await pool.query(insertMemberSql, [
            quizId,
            userId,
            finalRole
        ]);

        return res.json({
            success: true,
            data: {
                quizId,
                userId,
                role: finalRole
            }
        });

    } catch (error) {
        console.error("❌ SQL Error in handleAddQuizMember:", error);

        return res.status(500).json({
            success: false,
            message: "خطا در ثبت عضو آزمون در پایگاه داده"
        });
    }
};



const handleCheckUserMember = async (req, res) => {
    try {
        const { userId, quizId } = req.body;

        if (!userId || !quizId) {
            return res.status(400).json({
                success: false,
                message: "userId and quizId are required",
                isMember: false,
            });
        }

        let decodedQuizId;

        try {
            decodedQuizId = decodeQuizId(quizId);
        } catch (decodeError) {
            return res.status(400).json({
                success: false,
                message: "Invalid quizId",
                isMember: false,
            });
        }

        const [rows] = await pool.execute(
            `
            SELECT id
            FROM quiz_members
            WHERE user_id = ?
              AND quiz_id = ?
            LIMIT 1
            `,
            [userId, decodedQuizId]
        );

        return res.status(200).json({
            success: true,
            isMember: rows.length > 0,
        });
    } catch (error) {
        console.error("handleCheckUserMember error:", error);

        return res.status(500).json({
            success: false,
            message: "Internal server error",
            isMember: false,
        });
    }
};



const handleGetQuizByShareCode = async (req, res) => {
    try {
        const { shareCode } = req.body;

        if (!shareCode) {
            return res.json({ success: false, message: "کد اشتراک‌گذاری ارسال نشده است" });
        }

        const decodedShareCode = decodeShareCode(shareCode);

        if (!decodedShareCode) {
            return res.json({ success: false, message: "کد اشتراک‌گذاری نامعتبر است" });
        }

        const sql = `
            SELECT id, share_code, title, quiz_type, difficulty, time_limit, visibility, member_limit, settings
            FROM quizzes
            WHERE share_code = ?
            LIMIT 1
        `;

        const [rows] = await pool.query(sql, [decodedShareCode]);

        if (rows.length === 0) {
            return res.json({ success: false, message: "آزمون یافت نشد یا کد نامعتبر است" });
        }

        const quiz = rows[0];

        let parsedSettings = {};
        if (quiz.settings) {
            parsedSettings = typeof quiz.settings === 'string' ? JSON.parse(quiz.settings) : quiz.settings;
        }

        const selectionNames = parsedSettings.selectionNames || {};
        const seenIds = new Set();

        const formatSelections = (namesObj = {}) => {
            const result = [];
            for (const [id, title] of Object.entries(namesObj)) {
                if (!seenIds.has(id)) {
                    seenIds.add(id);
                    result.push({
                        id: Number(id) || id,
                        title: title
                    });
                }
            }
            return result;
        };

        return res.json({
            success: true,
            id: encodeQuizId(quiz.id),
            shareCode: encodeShareCode(quiz.share_code),
            quizName: quiz.title,
            quizType: quiz.quiz_type,
            settings: parsedSettings,
            lessons: formatSelections(selectionNames.lessonNames),
            grades: formatSelections(selectionNames.gradeNames),
            chapters: formatSelections(selectionNames.chapterNames),
            mabhas: formatSelections(selectionNames.mabhasNames)
        });

    } catch (error) {
        console.error("❌ SQL Error in handleGetQuizByShareCode:", error);
        return res.json({ success: false, message: "خطا در دریافت اطلاعات اتاق انتظار" });
    }
};




const QUIZ_META_SQL = `
            SELECT
                id,
                share_code,
                creator_id,
                title,
                quiz_type,
                difficulty,
                time_limit,
                visibility,
                member_limit,
                question_ids,
                settings
            FROM quizzes
`;

async function findQuizForMetadata(rawValue) {
    const raw = String(rawValue || '').trim();
    if (!raw) return null;

    if (/^\d+$/.test(raw)) {
        const [rows] = await pool.query(`${QUIZ_META_SQL} WHERE id = ? LIMIT 1`, [Number(raw)]);
        if (rows.length) return rows[0];
    }

    const quizId = decodeQuizId(raw);
    if (quizId) {
        const [rows] = await pool.query(`${QUIZ_META_SQL} WHERE id = ? LIMIT 1`, [quizId]);
        if (rows.length) return rows[0];
    }

    const shareId = decodeShareCode(raw);
    if (shareId) {
        const [rows] = await pool.query(`${QUIZ_META_SQL} WHERE share_code = ? LIMIT 1`, [shareId]);
        if (rows.length) return rows[0];
    }

    return null;
}

const handleGetQuizMetadata = async (req, res) => {
    try {
        const quiz = await findQuizForMetadata(req.params.quizId);

        if (!quiz) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'QUIZ_NOT_FOUND',
                    message: 'Quiz not found'
                }
            });
        }

        let questionIds = [];
        if (quiz.question_ids) {
            try {
                questionIds =
                    typeof quiz.question_ids === 'string'
                        ? JSON.parse(quiz.question_ids)
                        : quiz.question_ids;

                if (!Array.isArray(questionIds)) {
                    questionIds = [];
                }
            } catch (e) {
                questionIds = [];
            }
        }

        let parsedSettings = {};
        if (quiz.settings) {
            try {
                parsedSettings =
                    typeof quiz.settings === 'string'
                        ? JSON.parse(quiz.settings)
                        : quiz.settings;
            } catch (e) {
                parsedSettings = {};
            }
        }

        const timeLimitRaw = quiz.time_limit ?? parsedSettings.time ?? null;
        const timeLimitNumber = Number(timeLimitRaw);

        const durationSeconds =
            Number.isFinite(timeLimitNumber) && timeLimitNumber > 0
                ? timeLimitNumber
                : null;

        const metadata = {
            id: encodeQuizId(quiz.id),
            quizId: encodeQuizId(quiz.id),
            shareCode: encodeShareCode(quiz.share_code),
            title: quiz.title,
            ownerId: quiz.creator_id,
            creatorId: quiz.creator_id,
            quizType: quiz.quiz_type,
            difficulty: quiz.difficulty,
            visibility: quiz.visibility,
            memberLimit: quiz.member_limit,
            questionCount: questionIds.length,
            totalQuestions: questionIds.length,
            durationSeconds,
            timeLimit: quiz.time_limit,
            playable: questionIds.length > 0
        };

        return res.json({
            success: true,
            data: metadata
        });
    } catch (error) {
        console.error('❌ SQL Error in handleGetQuizMetadata:', error);

        return res.status(500).json({
            success: false,
            error: {
                code: 'QUIZ_METADATA_FAILED',
                message: 'Failed to fetch quiz metadata'
            }
        });
    }
};


const handleGetQuizPreviewState = async (req, res) => {
    try {
        const quizId = req.body.quizId;

        if (!quizId) {
            return res.status(400).json({
                success: false,
                error: {
                    code: 'INVALID_QUIZ_ID',
                    message: 'شناسه آزمون نامعتبر است'
                }
            });
        }
        const unhashedQuizId = decodeQuizId(quizId);

        // کوئری سبک: فقط فیلدهای ضروری برای منطق QuizPage دریافت می‌شوند
        const sql = `
            SELECT
                share_code,
                creator_id,
                status,
                time_limit,
                visibility
            FROM quizzes
            WHERE id = ?
            LIMIT 1
        `;

        const [rows] = await pool.query(sql, [unhashedQuizId]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: {
                    code: 'QUIZ_NOT_FOUND',
                    message: 'آزمون یافت نشد'
                }
            });
        }

        const quiz = rows[0];

        // شیء خروجی شامل دقیقاً همان کلیدهایی است که فرانت‌اند نیاز دارد
        const previewState = {
            code: encodeShareCode(quiz.share_code),
            creator_id: quiz.creator_id,
            status: quiz.status,
            visibility: quiz.visibility,
            time_limit: quiz.time_limit
        };

        return res.json({
            success: true,
            data: previewState
        });

    } catch (error) {
        console.error('❌ Error in handleGetQuizPreviewState:', error);

        return res.status(500).json({
            success: false,
            error: {
                code: 'PREVIEW_STATE_FAILED',
                message: 'خطا در دریافت وضعیت آزمون'
            }
        });
    }
};


const handleGetQuizQuestions = async (req, res) => {
    let connection;

    try {
        const { quizId } = req.body;
        const userId = req.user?.id;

        if (!userId) {
            return res.status(401).json({
                success: false,
                message: 'کاربر احراز هویت نشده است'
            });
        }

        if (!quizId || typeof quizId !== 'string') {
            return res.status(400).json({
                success: false,
                message: 'شناسه آزمون نامعتبر است'
            });
        }

        const decodedQuizId = decodeQuizId(quizId);

        if (!Number.isInteger(decodedQuizId) || decodedQuizId <= 0) {
            return res.status(400).json({
                success: false,
                message: 'شناسه آزمون نامعتبر است'
            });
        }

        connection = await pool.getConnection();

        /**
         * First check if this user already has a result for this quiz.
         * If yes, return resultId instead of questions.
         */
        const existingResult = await getExistingQuizResult(
            connection,
            decodedQuizId,
            userId
        );

        if (existingResult) {
            const existingId = await positiveResultId(
                connection,
                existingResult.id,
                decodedQuizId,
                userId
            );
            return res.status(200).json({
                success: true,
                resultId: clientResultId(existingId)
            });
        }

        await connection.beginTransaction();

        // 1. دریافت اطلاعات آزمون
        const [quizRows] = await connection.query(
            `SELECT id, question_ids, status
             FROM quizzes
             WHERE id = ?
             LIMIT 1`,
            [decodedQuizId]
        );

        if (quizRows.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                message: 'آزمون یافت نشد'
            });
        }

        const quiz = quizRows[0];

        let questionIds = [];

        try {
            questionIds =
                typeof quiz.question_ids === 'string'
                    ? JSON.parse(quiz.question_ids)
                    : quiz.question_ids;
        } catch (e) {
            questionIds = [];
        }

        // 2. آپدیت وضعیت آزمون
        await connection.query(
            `UPDATE quizzes
             SET status = 'in_progress'
             WHERE id = ? AND (status IS NULL OR status <> 'in_progress')`,
            [decodedQuizId]
        );

        await connection.commit();

        if (!Array.isArray(questionIds) || questionIds.length === 0) {
            return res.json({
                success: true,
                questions: []
            });
        }

        // 3. دریافت سوالات
        const sql = `
            SELECT
                q.id,
                q.question_text,
                q.academic_year,
                q.difficulty_level,
                q.grade_id,
                q.subject_id,
                q.topic_id,
                q.chapter_id,
                q.major_id,
                s.title AS subject_title,
                t.title AS topic_title,
                c.title AS chapter_title,
                g.title AS grade_title
            FROM questions_tam24 q
                     LEFT JOIN subjects_tam24 s ON q.subject_id = s.id
                     LEFT JOIN topics_tam24 t ON q.topic_id = t.id
                     LEFT JOIN chapters_tam24 c ON q.chapter_id = c.id
                     LEFT JOIN grades_tam24 g ON q.grade_id = g.id
            WHERE q.id IN (?)
            ORDER BY FIELD(q.id, ${questionIds.join(',')})
        `;

        const [questions] = await pool.query(sql, [questionIds]);

        // 4. ساخت خروجی نهایی
        const formattedQuestions = await Promise.all(
            questions.map(async (q) => {
                const rawOptions = await fetchQuestionOptions(q.id);
                const images = await fetchQuestionImages(q.id);

                const options = rawOptions.map((opt) => ({
                    id: opt.id,
                    text: opt.text || opt.option_text
                }));

                return {
                    id: q.id,
                    text: q.question_text,
                    options,
                    has_image: images.length > 0,
                    images,
                    grade: q.grade_title,
                    subject: q.subject_title,
                    topic: q.topic_title,
                    chapter: q.chapter_title,
                    grade_id: q.grade_id,
                    subject_id: q.subject_id,
                    topic_id: q.topic_id,
                    chapter_id: q.chapter_id,
                    major_id: q.major_id,
                    academic_year: q.academic_year,
                    difficulty_level: q.difficulty_level
                };
            })
        );

        return res.json({
            success: true,
            questions: formattedQuestions
        });

    } catch (error) {
        if (connection) {
            try {
                await connection.rollback();
            } catch (_) {}
        }

        console.error('❌ SQL Error in handleGetQuizQuestions:', error);

        return res.status(500).json({
            success: false,
            message: 'Database error fetching quiz questions'
        });
    } finally {
        if (connection) connection.release();
    }
};


async function handleSubmitQuizAnswers(req, res) {
    const userId = req.user?.id;

    const {
        quizId,
        answers,
        questionIds: submittedQuestionIds,
        timeSpent,
        questionTimes,
        selectionLog
    } = req.body || {};

    const isPlainObject = (value) =>
        value !== null &&
        typeof value === "object" &&
        !Array.isArray(value);

    const toPositiveInt = (value) => {
        const num = Number(value);
        return Number.isInteger(num) && num > 0 ? num : null;
    };

    const toNonNegativeInt = (value) => {
        const num = Number(value);
        return Number.isFinite(num) && num >= 0 ? Math.floor(num) : null;
    };

    if (!userId || !quizId || typeof quizId !== "string" || !isPlainObject(answers)) {
        return res.status(400).json({
            success: false,
            error: "Invalid payload. Need authenticated user, quizId, and answers object."
        });
    }

    if (submittedQuestionIds !== undefined && !Array.isArray(submittedQuestionIds)) {
        return res.status(400).json({
            success: false,
            error: "Invalid questionIds."
        });
    }

    if (timeSpent !== undefined && toNonNegativeInt(timeSpent) === null) {
        return res.status(400).json({
            success: false,
            error: "Invalid timeSpent."
        });
    }

    if (questionTimes !== undefined && !isPlainObject(questionTimes)) {
        return res.status(400).json({
            success: false,
            error: "Invalid questionTimes."
        });
    }

    if (selectionLog !== undefined && !Array.isArray(selectionLog)) {
        return res.status(400).json({
            success: false,
            error: "Invalid selectionLog."
        });
    }

    const decodedQuizId = decodeQuizId(quizId);

    if (!Number.isInteger(decodedQuizId) || decodedQuizId <= 0) {
        return res.status(400).json({
            success: false,
            error: "Invalid quizId."
        });
    }

    const sanitizedAnswers = {};
    for (const [questionIdRaw, optionIdRaw] of Object.entries(answers)) {
        const questionId = toPositiveInt(questionIdRaw);
        const optionId = toPositiveInt(optionIdRaw);

        if (questionId && optionId) {
            sanitizedAnswers[String(questionId)] = optionId;
        }
    }

    const sanitizedSubmittedQuestionIds = Array.isArray(submittedQuestionIds)
        ? submittedQuestionIds
            .map((id) => toPositiveInt(id))
            .filter((id) => id !== null)
        : [];

    const sanitizedQuestionTimes = {};
    if (isPlainObject(questionTimes)) {
        for (const [questionIdRaw, timeRaw] of Object.entries(questionTimes)) {
            const questionId = toPositiveInt(questionIdRaw);
            const timeValue = toNonNegativeInt(timeRaw);

            if (questionId && timeValue !== null) {
                sanitizedQuestionTimes[String(questionId)] = timeValue;
            }
        }
    }

    const sanitizedSelectionLog = Array.isArray(selectionLog)
        ? selectionLog
            .filter((entry) => isPlainObject(entry))
            .map((entry) => {
                const questionId = toPositiveInt(entry.questionId);
                const optionId = toPositiveInt(entry.optionId);
                const timeSpentMs = toNonNegativeInt(entry.timeSpentMs);
                const timestamp = toNonNegativeInt(entry.timestamp);

                if (!questionId || !optionId || timeSpentMs === null || timestamp === null) {
                    return null;
                }

                return {
                    questionId,
                    optionId,
                    timeSpentMs,
                    timestamp
                };
            })
            .filter(Boolean)
        : [];

    const sanitizedTotalTimeSpent = toNonNegativeInt(timeSpent) ?? 0;

    let connection;

    try {
        await ensureVisitorCountIds();
        connection = await pool.getConnection();
        await connection.beginTransaction();

        const quiz = await getQuizById(connection, decodedQuizId);

        if (!quiz) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                error: "Quiz not found."
            });
        }

        const questionIds = parseQuestionIds(quiz.question_ids);

        if (questionIds.length === 0) {
            await connection.rollback();
            return res.status(400).json({
                success: false,
                error: "Quiz has no valid questions."
            });
        }

        const validQuestionIdSet = new Set(questionIds);

        const filteredAnswers = {};
        for (const [questionIdStr, optionId] of Object.entries(sanitizedAnswers)) {
            const questionId = Number(questionIdStr);
            if (validQuestionIdSet.has(questionId)) {
                filteredAnswers[questionIdStr] = optionId;
            }
        }

        const filteredSubmittedQuestionIds = sanitizedSubmittedQuestionIds.filter((id) =>
            validQuestionIdSet.has(id)
        );

        const filteredQuestionTimes = {};
        for (const [questionIdStr, timeValue] of Object.entries(sanitizedQuestionTimes)) {
            const questionId = Number(questionIdStr);
            if (validQuestionIdSet.has(questionId)) {
                filteredQuestionTimes[questionIdStr] = timeValue;
            }
        }

        const filteredSelectionLog = sanitizedSelectionLog.filter((entry) =>
            validQuestionIdSet.has(entry.questionId)
        );

        const existingResult = await getExistingQuizResult(
            connection,
            decodedQuizId,
            userId
        );

        if (existingResult) {
            const existingId = await positiveResultId(connection, existingResult.id, decodedQuizId, userId);
            await connection.commit();

            const publicId = clientResultId(existingId);
            if (!publicId) {
                return res.status(500).json({
                    success: false,
                    error: "شناسه نتیجه از سمت سرور دریافت نشد."
                });
            }
            return res.status(200).json({
                success: true,
                resultId: publicId
            });
        }

        const user = await getUserXpInfo(connection, userId);

        if (!user) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                error: "User not found."
            });
        }

        const metadata = await getQuizEvaluationMetadata(
            connection,
            questionIds,
            userId
        );

        const evaluation = evaluateQuizSubmission({
            questionIds,
            submittedAnswers: filteredAnswers,
            correctOptionsMap: metadata.correctOptionsMap,
            descriptiveMap: metadata.descriptiveMap,
            questionMetaMap: metadata.questionMetaMap
        });

        const enrichedEvaluation = {};

        if (evaluation.resultData && typeof evaluation.resultData === "object") {
            for (const questionId of questionIds) {
                const key = String(questionId);
                const item = evaluation.resultData[key];

                if (!item || typeof item !== "object") {
                    continue;
                }

                enrichedEvaluation[key] = {
                    ...item,
                    selected_option_id: filteredAnswers[key] ?? null,
                    is_answered: Object.prototype.hasOwnProperty.call(filteredAnswers, key)
                };
            }
        }

        const answerMutations = buildUserAnswerMutations({
            userId,
            questionIds,
            resultData: evaluation.resultData,
            existingAnswersMap: metadata.existingAnswersMap
        });

        const xpResult = applyXpProgression({
            currentXpPoints: Number(user.xp_points || 0),
            currentXpLevel: Number(user.xp_level || 1),
            gainedXp: evaluation.totalXpGain
        });

        const resultDataToStore = {
            evaluation: enrichedEvaluation,
            submission: {
                submittedAnswers: filteredAnswers,
                submittedQuestionIds: filteredSubmittedQuestionIds,
                totalTimeSpent: sanitizedTotalTimeSpent,
                questionTimes: filteredQuestionTimes,
                selectionLog: filteredSelectionLog
            }
        };

        const numericResultId = await insertQuizResult(connection, {
            quizId: decodedQuizId,
            userId,
            correctCount: evaluation.summary.correct_count,
            incorrectCount: evaluation.summary.incorrect_count,
            unansweredCount: evaluation.summary.unanswered_count,
            accuracyRate: evaluation.summary.accuracy_rate,
            score: evaluation.summary.score,
            totalTimeSpent: sanitizedTotalTimeSpent,
            summary: evaluation.summary,
            resultData: resultDataToStore
        });

        await persistUserAnswerMutations(connection, answerMutations);

        await updateUserXp(connection, {
            userId,
            xpPoints: xpResult.updatedXpPoints,
            xpLevel: xpResult.updatedXpLevel
        });

        await connection.commit();

        const publicId = clientResultId(numericResultId);
        if (!publicId) {
            return res.status(500).json({
                success: false,
                error: "شناسه نتیجه از سمت سرور دریافت نشد."
            });
        }

        return res.status(200).json({
            success: true,
            resultId: publicId
        });
    } catch (error) {
        if (connection) {
            try {
                await connection.rollback();
            } catch (_) {}
        }

        console.error("Error in handleSubmitQuizAnswers:", error);

        if (error && (error.code === "ER_DUP_ENTRY" || error.errno === 1062)) {
            let fallbackConnection;

            try {
                fallbackConnection = await pool.getConnection();

                const existingResult = await getExistingQuizResult(
                    fallbackConnection,
                    decodedQuizId,
                    userId
                );

                if (existingResult) {
                    const existingId = await positiveResultId(
                        fallbackConnection,
                        existingResult.id,
                        decodedQuizId,
                        userId
                    );
                    const publicId = clientResultId(existingId);
                    if (!publicId) {
                        return res.status(500).json({
                            success: false,
                            error: "شناسه نتیجه از سمت سرور دریافت نشد."
                        });
                    }
                    return res.status(200).json({
                        success: true,
                        resultId: publicId
                    });
                }
            } catch (fallbackError) {
                console.error("Fallback duplicate-result fetch failed:", fallbackError);
            } finally {
                if (fallbackConnection) {
                    fallbackConnection.release();
                }
            }
        }

        return res.status(500).json({
            success: false,
            error: "Internal server error."
        });
    } finally {
        if (connection) {
            connection.release();
        }
    }
}


async function getQuizById(connection, quizId) {
    const [rows] = await connection.query(`
        SELECT id, question_ids, status
        FROM quizzes
        WHERE id = ?
        LIMIT 1
    `, [quizId]);

    return rows.length ? rows[0] : null;
}

async function isQuizPublic(connection, quizId) {
    const [rows] = await connection.query(`
        SELECT visibility
        FROM quizzes
        WHERE id = ?
        LIMIT 1
    `, [quizId]);

    return rows.length > 0 && rows[0].visibility === 'public';
}


function parseQuestionIds(rawQuestionIds) {
    let parsed = rawQuestionIds;

    try {
        if (typeof rawQuestionIds === "string") {
            parsed = JSON.parse(rawQuestionIds);
        }
    } catch (error) {
        return [];
    }

    if (!Array.isArray(parsed)) {
        return [];
    }

    return [...new Set(
        parsed
            .map(Number)
            .filter(id => Number.isInteger(id) && id > 0)
    )];
}

async function getExistingQuizResult(connection, quizId, userId) {
    const [rows] = await connection.query(`
        SELECT 
            id,
            quiz_id,
            user_id,
            correct_count,
            incorrect_count,
            unanswered_count,
            accuracy_rate,
            total_score,
            summary_json,
            result_data_json
        FROM quiz_results
        WHERE quiz_id = ? AND user_id = ?
        LIMIT 1
    `, [quizId, userId]);

    return rows.length ? rows[0] : null;
}

/** A missing AUTO_INCREMENT writes id 0, which cannot be encoded for the result page. */
async function positiveResultId(connection, insertId, quizId, userId) {
    let id = Number(insertId);
    if (Number.isInteger(id) && id > 0) return id;

    const existing = await getExistingQuizResult(connection, quizId, userId);
    id = Number(existing?.id);
    if (Number.isInteger(id) && id > 0) return id;
    if (!existing) return null;

    const [[maxRow]] = await connection.query(
        'SELECT COALESCE(MAX(id), 0) AS maxId FROM quiz_results'
    );
    const nextId = Number(maxRow?.maxId || 0) + 1;
    await connection.query(
        'UPDATE quiz_results SET id = ? WHERE id = 0 AND quiz_id = ? AND user_id = ? LIMIT 1',
        [nextId, quizId, userId]
    );
    return nextId;
}

/** Hash the row id for /result/:resultId. A positive numeric id still works if hashing fails. */
function clientResultId(numericId) {
    const encoded = encodeResultId(numericId);
    if (encoded) return encoded;
    const id = Number(numericId);
    return Number.isInteger(id) && id > 0 ? String(id) : null;
}

async function getUserXpInfo(connection, userId) {
    const [rows] = await connection.query(`
        SELECT id, xp_points, xp_level
        FROM tam24_users
        WHERE id = ?
        LIMIT 1
    `, [userId]);

    return rows.length ? rows[0] : null;
}


function generateScoreExplanation(evalResult) {
    const {
        finalScore,
        totalCorrect,
        totalWrong,
        totalUnanswered,
        weightedScore,
        weightedNegative,
        totalWeight
    } = evalResult;

    // 1. Determine the tone/prefix based on the score range
    let rangeNote = "";
    if (finalScore >= 90) {
        rangeNote = "عملکرد فوق‌العاده‌ای داشتید!";
    } else if (finalScore >= 70) {
        rangeNote = "خسته نباشید! شما تسلط خوبی بر مباحث دارید.";
    } else if (finalScore >= 50) {
        rangeNote = "شما قبول شدید، اما هنوز جای پیشرفت وجود دارد.";
    } else if (finalScore > 0) {
        rangeNote = "به تمرین ادامه دهید. برای بهبود نمره، پاسخ‌های اشتباه خود را مرور کنید.";
    } else {
        rangeNote = "متاسفانه به دلیل نمره منفی یا سوالات بی‌پاسخ، نمره شما صفر شد.";
    }

    // 2. Build the exact mathematical explanation in Persian
    const mathExplanation = `شما به ${totalCorrect} سوال پاسخ صحیح و به ${totalWrong} سوال پاسخ غلط دادید و ${totalUnanswered} سوال را بی‌پاسخ گذاشتید. ` +
        `بابت پاسخ‌های صحیح ${weightedScore.toFixed(2)} امتیاز کسب کردید. ` +
        `با توجه به اینکه هر پاسخ غلط دارای $1/3$ نمره منفی است، ${weightedNegative.toFixed(2)} امتیاز از شما کسر شد. ` +
        `نمره خام شما از مجموع حداکثر ${totalWeight} امتیاز ممکن محاسبه گردید که در نهایت نمره تراز شده ${finalScore} از $100$ برای شما منظور شد.`;

    // 3. Combine into a final paragraph
    return `${rangeNote} ${mathExplanation}`;
}





async function getQuizEvaluationMetadata(connection, questionIds, userId) {
    const placeholders = questionIds.map(() => "?").join(",");

    const [optionsRows] = await connection.query(`
        SELECT question_id, id AS correct_option_id
        FROM options_tam24
        WHERE question_id IN (${placeholders}) AND is_correct = 1
    `, questionIds);

    const [descriptiveRows] = await connection.query(`
        SELECT question_id, answer_text
        FROM descriptive_answers_tam24
        WHERE question_id IN (${placeholders})
    `, questionIds);

    const [questionsRows] = await connection.query(`
        SELECT 
            q.id AS question_id,
            q.difficulty_level AS level,
            q.topic_id,
            t.title AS topic_title
        FROM questions_tam24 q
        LEFT JOIN topics_tam24 t ON q.topic_id = t.id
        WHERE q.id IN (${placeholders})
    `, questionIds);

    const [existingAnswersRows] = await connection.query(`
        SELECT question_id, status
        FROM tam24_user_answers
        WHERE user_id = ? AND question_id IN (${placeholders})
    `, [userId, ...questionIds]);

    const correctOptionsMap = {};
    for (const row of optionsRows) {
        correctOptionsMap[row.question_id] = row.correct_option_id;
    }

    const descriptiveMap = {};
    for (const row of descriptiveRows) {
        descriptiveMap[row.question_id] = row.answer_text;
    }

    const questionMetaMap = {};
    for (const row of questionsRows) {
        questionMetaMap[row.question_id] = {
            level: row.level || "متوسط",
            topic_id: row.topic_id || null,
            topic_title: row.topic_title || "نامشخص"
        };
    }

    const existingAnswersMap = {};
    for (const row of existingAnswersRows) {
        existingAnswersMap[row.question_id] = row.status;
    }

    return {
        correctOptionsMap,
        descriptiveMap,
        questionMetaMap,
        existingAnswersMap
    };
}

function getQuestionWeight(level) {
    if (level === "آسان" || level === "easy") return 1;
    if (level === "سخت" || level === "hard") return 3;
    return 2;
}

function getXpForQuestionStatus(status, weight) {
    if (status === "correct") {
        if (weight === 1) return 8;
        if (weight === 3) return 18;
        return 12;
    }

    if (status === "wrong") {
        return 1;
    }

    return 2;
}

function calculateCompetitiveScore({
                                       weightedPositive,
                                       weightedNegative,
                                       weightedMaxPossible
                                   }) {
    if (!weightedMaxPossible || weightedMaxPossible <= 0) {
        return 0;
    }

    const rawScore = ((weightedPositive - weightedNegative) / weightedMaxPossible) * 100;
    const rounded = Math.round(rawScore);

    if (rounded < 0) return 0;
    if (rounded > 100) return 100;
    return rounded;
}

function calculateAccuracyRate({
                                   correctCount,
                                   totalQuestions
                               }) {
    if (!totalQuestions || totalQuestions <= 0) {
        return 0;
    }

    const rawAccuracy = (Number(correctCount || 0) / Number(totalQuestions)) * 100;
    return Number(rawAccuracy.toFixed(2));
}

function getQuizCompletionBonusXp(score) {
    let bonusXp = 5;

    if (score >= 90) bonusXp += 20;
    else if (score >= 75) bonusXp += 12;
    else if (score >= 60) bonusXp += 8;

    return bonusXp;
}

function evaluateQuizSubmission({
                                    questionIds,
                                    submittedAnswers,
                                    correctOptionsMap,
                                    descriptiveMap,
                                    questionMetaMap
                                }) {
    let correctCount = 0;
    let incorrectCount = 0;
    let unansweredCount = 0;

    let weightedPositive = 0;
    let weightedNegative = 0;
    let weightedMaxPossible = 0;

    let totalXpGain = 0;

    const mabhasStats = {};
    const resultData = {};

    const ensureMabhasStats = (mabhas) => {
        if (!mabhasStats[mabhas]) {
            mabhasStats[mabhas] = {
                correct: 0,
                incorrect: 0,
                unanswered: 0,
                total: 0
            };
        }
    };

    for (const qId of questionIds) {
        const hasAnswer = Object.prototype.hasOwnProperty.call(submittedAnswers, qId);
        const submittedAnswer = hasAnswer ? submittedAnswers[qId] : undefined;

        const correctOptionId = correctOptionsMap[qId] || null;
        const meta = questionMetaMap[qId] || {};
        const level = meta.level || "متوسط";
        const mabhas = meta.topic_title || "نامشخص";
        const weight = getQuestionWeight(level);

        ensureMabhasStats(mabhas);

        weightedMaxPossible += weight;

        let status = "unanswered";

        if (
            submittedAnswer === undefined ||
            submittedAnswer === null ||
            submittedAnswer === ""
        ) {
            status = "unanswered";
            unansweredCount += 1;
            mabhasStats[mabhas].unanswered += 1;
        } else if (String(submittedAnswer) === String(correctOptionId) && correctOptionId !== null) {
            status = "correct";
            correctCount += 1;
            weightedPositive += weight;
            mabhasStats[mabhas].correct += 1;
        } else {
            status = "wrong";
            incorrectCount += 1;
            weightedNegative += (weight / 3);
            mabhasStats[mabhas].incorrect += 1;
        }

        mabhasStats[mabhas].total += 1;

        const earnedXp = getXpForQuestionStatus(status, weight);
        totalXpGain += earnedXp;

        resultData[qId] = {
            correct_option_id: correctOptionId,
            descriptive_answer: {
                text: descriptiveMap[qId] || null
            },
            status,
            level,
            mabhas
        };
    }

    const score = calculateCompetitiveScore({
        weightedPositive,
        weightedNegative,
        weightedMaxPossible
    });
    const scoreExplanation = generateScoreExplanation({
        finalScore: score,
        totalCorrect: correctCount,
        totalWrong: incorrectCount,
        totalUnanswered: unansweredCount,
        weightedScore: weightedPositive,
        weightedNegative: weightedNegative,
        totalWeight: weightedMaxPossible
    });

    const accuracyRate = calculateAccuracyRate({
        correctCount,
        totalQuestions: questionIds.length
    });

    totalXpGain += getQuizCompletionBonusXp(score);

    return {
        totalXpGain,
        resultData,
        summary: {
            total_questions: questionIds.length,
            correct_count: correctCount,
            incorrect_count: incorrectCount,
            unanswered_count: unansweredCount,
            accuracy_rate: accuracyRate,
            score,
            mabhas_stats: mabhasStats
        }
    };
}

function buildUserAnswerMutations({
                                      userId,
                                      questionIds,
                                      resultData,
                                      existingAnswersMap
                                  }) {
    const inserts = [];
    const updates = [];

    for (const qId of questionIds) {
        const newStatus = resultData[qId]?.status || "unanswered";
        const existingStatus = existingAnswersMap[qId];

        if (!existingStatus) {
            inserts.push([userId, qId, newStatus]);
        } else if (existingStatus !== newStatus) {
            updates.push([newStatus, userId, qId]);
        }
    }

    return { inserts, updates };
}

function applyXpProgression({
                                currentXpPoints,
                                currentXpLevel,
                                gainedXp
                            }) {
    let updatedXpPoints = Number(currentXpPoints || 0);
    let updatedXpLevel = Number(currentXpLevel || 1);

    updatedXpPoints += Number(gainedXp || 0);

    while (true) {
        const requiredXpForNextLevel = 100 + ((updatedXpLevel - 1) * 25);

        if (updatedXpPoints >= requiredXpForNextLevel) {
            updatedXpPoints -= requiredXpForNextLevel;
            updatedXpLevel += 1;
        } else {
            break;
        }
    }

    return {
        updatedXpPoints,
        updatedXpLevel
    };
}

async function insertQuizResult(connection, {
    quizId,
    userId,
    correctCount,
    incorrectCount,
    unansweredCount,
    accuracyRate,
    score,
    totalTimeSpent,
    summary,
    resultData
}) {
    const [result] = await connection.query(`
        INSERT INTO quiz_results
        (
            quiz_id,
            user_id,
            correct_count,
            incorrect_count,
            unanswered_count,
            accuracy_rate,
            total_score,
            total_time_spent,
            summary_json,
            result_data_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
        quizId,
        userId,
        correctCount,
        incorrectCount,
        unansweredCount,
        accuracyRate,
        score,
        totalTimeSpent,
        JSON.stringify(summary ?? {}),
        JSON.stringify(resultData ?? {})
    ]);

    return positiveResultId(connection, result.insertId, quizId, userId);
}

async function persistUserAnswerMutations(connection, { inserts, updates }) {
    if (inserts.length > 0) {
        await connection.query(`
            INSERT INTO tam24_user_answers (user_id, question_id, status)
            VALUES ?
        `, [inserts]);
    }

    for (const params of updates) {
        await connection.query(`
            UPDATE tam24_user_answers
            SET status = ?
            WHERE user_id = ? AND question_id = ?
        `, params);
    }
}

async function updateUserXp(connection, { userId, xpPoints, xpLevel }) {
    await connection.query(`
        UPDATE tam24_users
        SET xp_points = ?, xp_level = ?
        WHERE id = ?
    `, [xpPoints, xpLevel, userId]);
}

function safeJsonParse(value, fallback = null) {
    if (value == null) return fallback;
    if (typeof value === "object") return value;

    try {
        return JSON.parse(value);
    } catch (error) {
        return fallback;
    }
}

function httpError(message, statusCode) {
    const error = new Error(message);
    error.statusCode = statusCode;
    return error;
}

/**
 * Insert the graded attempt and return its numeric quiz_results id.
 * A second call for the same quiz and user returns the existing id and does not grant XP again.
 */
async function persistGradedAttempt({
    decodedQuizId,
    userId,
    lobbyCode,
    evaluation,
    formattedAnswers,
    timeSpent,
    questionTimes,
    selectionLog
}) {
    if (!evaluation || !evaluation.summary || !evaluation.resultData) {
        throw httpError("Invalid grade payload.", 400);
    }

    const toPositiveInt = (v) => {
        const n = Number(v);
        return Number.isInteger(n) && n > 0 ? n : null;
    };

    const toNonNegativeInt = (v) => {
        const n = Number(v);
        return Number.isFinite(n) && n >= 0 ? Math.floor(n) : null;
    };

    const spent = toNonNegativeInt(timeSpent) ?? 0;

    const sanitizedQuestionTimes = {};
    if (questionTimes && typeof questionTimes === "object" && !Array.isArray(questionTimes)) {
        for (const [qid, time] of Object.entries(questionTimes)) {
            const questionId = toPositiveInt(qid);
            const value = toNonNegativeInt(time);
            if (questionId && value !== null) {
                sanitizedQuestionTimes[String(questionId)] = value;
            }
        }
    }

    const sanitizedSelectionLog = Array.isArray(selectionLog)
        ? selectionLog
            .map((entry) => {
                const questionId = toPositiveInt(entry?.questionId);
                const optionId = toPositiveInt(entry?.optionId);
                const timeSpentMs = toNonNegativeInt(entry?.timeSpentMs);
                const timestamp = toNonNegativeInt(entry?.timestamp);
                if (!questionId || !optionId || timeSpentMs === null || timestamp === null) {
                    return null;
                }
                return { questionId, optionId, timeSpentMs, timestamp };
            })
            .filter(Boolean)
        : [];

    await ensureVisitorCountIds();
    const connection = await pool.getConnection();

    try {
        await connection.beginTransaction();

        const quiz = await getQuizById(connection, decodedQuizId);
        const user = await getUserXpInfo(connection, userId);

        if (!quiz || !user) {
            await connection.rollback();
            throw httpError("Quiz or User not found.", 404);
        }

        const existingResult = await getExistingQuizResult(connection, decodedQuizId, userId);
        if (existingResult) {
            const existingId = await positiveResultId(
                connection,
                existingResult.id,
                decodedQuizId,
                userId
            );
            await connection.commit();
            if (!existingId) throw httpError("Result id was not created.", 500);
            return existingId;
        }

        const questionIds = parseQuestionIds(quiz.question_ids);
        const answers = formattedAnswers && typeof formattedAnswers === "object" ? formattedAnswers : {};
        const metadata = await getQuizEvaluationMetadata(connection, questionIds, userId);

        const answerMutations = buildUserAnswerMutations({
            userId,
            questionIds,
            resultData: evaluation.resultData,
            existingAnswersMap: metadata.existingAnswersMap
        });

        const xpResult = applyXpProgression({
            currentXpPoints: Number(user.xp_points || 0),
            currentXpLevel: Number(user.xp_level || 1),
            gainedXp: evaluation.totalXpGain
        });

        const enrichedEvaluation = {};
        for (const qid of questionIds) {
            const key = String(qid);
            const item = evaluation.resultData[key];
            if (!item) continue;
            enrichedEvaluation[key] = {
                ...item,
                selected_option_id: answers[key] ?? null,
                is_answered: Object.prototype.hasOwnProperty.call(answers, key)
            };
        }

        const savedResultId = await insertQuizResult(connection, {
            quizId: decodedQuizId,
            userId,
            correctCount: evaluation.summary.correct_count,
            incorrectCount: evaluation.summary.incorrect_count,
            unansweredCount: evaluation.summary.unanswered_count,
            accuracyRate: evaluation.summary.accuracy_rate,
            score: evaluation.summary.score,
            totalTimeSpent: spent,
            summary: evaluation.summary,
            resultData: {
                evaluation: enrichedEvaluation,
                submission: {
                    submittedAnswers: answers,
                    totalTimeSpent: spent,
                    questionTimes: sanitizedQuestionTimes,
                    selectionLog: sanitizedSelectionLog,
                    lobbyCode: lobbyCode || null
                }
            }
        });

        await persistUserAnswerMutations(connection, answerMutations);
        await updateUserXp(connection, {
            userId,
            xpPoints: xpResult.updatedXpPoints,
            xpLevel: xpResult.updatedXpLevel
        });
        await connection.commit();

        if (!savedResultId) throw httpError("Result id was not created.", 500);
        return savedResultId;
    } catch (error) {
        try { await connection.rollback(); } catch (_) {}

        if (error && (error.code === "ER_DUP_ENTRY" || error.errno === 1062)) {
            const fallback = await pool.getConnection();
            try {
                const existingResult = await getExistingQuizResult(fallback, decodedQuizId, userId);
                const existingId = existingResult
                    ? await positiveResultId(fallback, existingResult.id, decodedQuizId, userId)
                    : null;
                if (existingId) return existingId;
            } finally {
                fallback.release();
            }
        }

        throw error;
    } finally {
        connection.release();
    }
}

async function handleInternalGradeQuiz(req, res) {
    const { quizId } = req.params;
    const { userId, lobbyCode, answers, timeSpent, questionTimes, selectionLog } = req.body || {};

    if (!answers || typeof answers !== "object" || Array.isArray(answers)) {
        return res.status(400).json({ error: "Invalid payload. Expected answers to be an object map." });
    }

    const decodedQuizId = decodeQuizId(quizId);
    if (!Number.isInteger(decodedQuizId) || decodedQuizId <= 0) {
        return res.status(400).json({ error: "Invalid quizId." });
    }

    let connection;

    try {
        connection = await pool.getConnection();
        const quiz = await getQuizById(connection, decodedQuizId);

        if (!quiz) {
            return res.status(404).json({ error: "Quiz not found." });
        }

        const questionIds = parseQuestionIds(quiz.question_ids);
        const formattedAnswers = answers;
        const metadata = await getQuizEvaluationMetadata(connection, questionIds, userId);
        const evaluation = evaluateQuizSubmission({
            questionIds,
            submittedAnswers: formattedAnswers,
            correctOptionsMap: metadata.correctOptionsMap,
            descriptiveMap: metadata.descriptiveMap,
            questionMetaMap: metadata.questionMetaMap
        });

        connection.release();
        connection = null;

        let resultId = null;
        if (userId) {
            const numericResultId = await persistGradedAttempt({
                decodedQuizId,
                userId,
                lobbyCode,
                evaluation,
                formattedAnswers,
                timeSpent: timeSpent || 0,
                questionTimes: questionTimes || {},
                selectionLog: selectionLog || []
            });
            resultId = clientResultId(numericResultId);
            if (!resultId) {
                return res.status(500).json({ error: "Result id was not created." });
            }
        }

        return res.status(200).json({
            resultId,
            id: resultId,
            score: evaluation.summary.score,
            total: questionIds.length,
            correctCount: evaluation.summary.correct_count,
            wrongCount: evaluation.summary.incorrect_count,
            evaluationData: evaluation,
            formattedAnswers,
            timeSpent: timeSpent || 0,
            questionTimes: questionTimes || {},
            selectionLog: selectionLog || []
        });
    } catch (error) {
        console.error("Error in handleInternalGradeQuiz:", error);
        const status = Number(error.statusCode) || 500;
        return res.status(status).json({
            error: status === 404 ? "Quiz or User not found." : "Internal server error."
        });
    } finally {
        if (connection) connection.release();
    }
}

// Saves the result, applies XP, and saves individual answers
async function handleInternalSaveQuizResult(req, res) {
    const { quizId, userId, lobbyCode, result } = req.body || {};

    if (!userId || !quizId || !result) {
        return res.status(400).json({ error: "Invalid payload." });
    }

    const decodedQuizId = decodeQuizId(quizId);
    if (!Number.isInteger(decodedQuizId) || decodedQuizId <= 0) {
        return res.status(400).json({ error: "Invalid quizId." });
    }

    try {
        const numericResultId = await persistGradedAttempt({
            decodedQuizId,
            userId,
            lobbyCode,
            evaluation: result.evaluationData,
            formattedAnswers: result.formattedAnswers || {},
            timeSpent: result.timeSpent,
            questionTimes: result.questionTimes,
            selectionLog: result.selectionLog
        });
        const publicId = clientResultId(numericResultId);
        if (!publicId) {
            return res.status(500).json({ error: "Result id was not created." });
        }

        return res.status(200).json({
            success: true,
            resultId: publicId,
            id: publicId
        });
    } catch (error) {
        console.error("Error in handleInternalSaveQuizResult:", error);
        const status = Number(error.statusCode) || 500;
        return res.status(status).json({
            error: status === 404 ? "Quiz or User not found." : "Internal server error."
        });
    }
}


function safeJsonParse(value, fallback = null) {
    if (value == null) return fallback;

    if (typeof value === "object") {
        return value;
    }

    try {
        return JSON.parse(value);
    } catch (_) {
        return fallback;
    }
}

async function getQuizResultById(connection, {
    resultId,
    userId
}) {
        const [rows] = await connection.query(`
        SELECT
            r.id,
            r.quiz_id,
            r.user_id,
            r.correct_count,
            r.incorrect_count,
            r.unanswered_count,
            r.accuracy_rate,
            r.total_score,
            r.summary_json,
            r.result_data_json,
            r.created_at,
            q.title AS quiz_title,
            u.avatar_url
        FROM quiz_results r
        LEFT JOIN quizzes q ON q.id = r.quiz_id
        LEFT JOIN tam24_users u ON u.id = r.user_id
        WHERE r.id = ?
          AND r.user_id = ?
        LIMIT 1
    `, [
        resultId,
        userId
    ]);

    if (!rows.length) {
        return null;
    }

    const row = rows[0];

    return {
        id: row.id,
        quizId: row.quiz_id,
        quizName: row.quiz_title || null,
        avatarUrl: row.avatar_url || null,
        userId: row.user_id,
        correctCount: row.correct_count,
        incorrectCount: row.incorrect_count,
        unansweredCount: row.unanswered_count,
        accuracyRate: row.accuracy_rate,
        score: row.total_score,
        summary: safeJsonParse(row.summary_json, {}),
        resultData: safeJsonParse(row.result_data_json, []),
        createdAt: row.created_at
    };
}


async function handleGetQuizResult(req, res) {
    let connection;

    try {
        const { resultId } = req.body;
        const userId = req.user?.id;

        const decodedResultId = decodeResultId(resultId);

        if (!decodedResultId) {
            return res.status(400).json({ error: "شناسه نتیجه نامعتبر است." });
        }

        connection = await pool.getConnection();

        const result = await getQuizResultById(connection, {
            resultId: decodedResultId,
            userId,
        });

        if (!result) {
            return res.status(404).json({ error: "نتیجه‌ای یافت نشد." });
        }

        const rawResultData = result.resultData || {};
        const evaluation = rawResultData.evaluation && typeof rawResultData.evaluation === 'object'
            ? rawResultData.evaluation
            : {};
        const submission = rawResultData.submission && typeof rawResultData.submission === 'object'
            ? rawResultData.submission
            : {};

        const submittedAnswers =
            submission.submittedAnswers && typeof submission.submittedAnswers === 'object'
                ? submission.submittedAnswers
                : {};

        const questionTimes =
            submission.questionTimes && typeof submission.questionTimes === 'object'
                ? submission.questionTimes
                : {};

        const selectionLog = Array.isArray(submission.selectionLog)
            ? submission.selectionLog
            : [];

        const questionIds = Object.keys(evaluation).filter((key) => /^\d+$/.test(key));

        if (questionIds.length > 0) {
            const placeholders = questionIds.map(() => '?').join(',');

            const [questions] = await connection.query(
                `
                SELECT 
                    q.id AS question_id,
                    q.question_text,
                    o.id AS option_id,
                    o.option_text
                FROM questions_tam24 q
                LEFT JOIN options_tam24 o ON q.id = o.question_id
                WHERE q.id IN (${placeholders})
                `,
                questionIds
            );

            const questionDetailsMap = {};

            for (const row of questions) {
                if (!questionDetailsMap[row.question_id]) {
                    questionDetailsMap[row.question_id] = {
                        question_text: row.question_text || "متن سوال یافت نشد",
                        options: [],
                    };
                }

                if (row.option_id) {
                    questionDetailsMap[row.question_id].options.push({
                        id: row.option_id,
                        text: row.option_text,
                    });
                }
            }

            await attachQuestionImages(connection, questionIds, questionDetailsMap);

            for (const qId of questionIds) {
                const details = questionDetailsMap[qId] || {
                    question_text: "متن سوال یافت نشد",
                    options: [],
                    images: [],
                };

                evaluation[qId] = {
                    ...evaluation[qId],
                    question_text: details.question_text,
                    options: details.options,
                    images: details.images || [],
                    selected_option_id:
                        evaluation[qId]?.selected_option_id ??
                        submittedAnswers[qId] ??
                        null,
                    is_answered:
                        typeof evaluation[qId]?.is_answered === 'boolean'
                            ? evaluation[qId].is_answered
                            : submittedAnswers[qId] != null,
                    time_spent_ms:
                        Number.isFinite(Number(questionTimes[qId]))
                            ? Number(questionTimes[qId])
                            : 0,
                };
            }
        }
        const is_public = await isQuizPublic(connection, result.quizId);
        const formattedResult = {
            id: encodeResultId(result.id),
            quizId: encodeQuizId(result.quizId),
            quizName: result.quizName || null,
            avatarUrl: result.avatarUrl || null,
            is_public: is_public,
            userId: result.userId,
            success: result.success,
            correctCount: result.correctCount,
            incorrectCount: result.incorrectCount,
            unansweredCount: result.unansweredCount || 0,
            accuracyRate: result.accuracyRate,
            score: result.score,
            total_time_spent:
                Number.isFinite(Number(result.total_time_spent)) && Number(result.total_time_spent) > 0
                    ? Number(result.total_time_spent)
                    : Number(submission.totalTimeSpent) || 0,
            summary: result.summary,
            resultData: {
                evaluation,
                submission: {
                    ...submission,
                    totalTimeSpent: Number(submission.totalTimeSpent) || 0,
                    questionTimes,
                    selectionLog,
                    submittedAnswers,
                },
            },
        };

        return res.status(200).json(formattedResult);
    } catch (error) {
        console.error("Error in handleGetQuizResult:", error);
        return res.status(500).json({ error: "خطای سرور در دریافت نتیجه آزمون." });
    } finally {
        if (connection) connection.release();
    }
}




// Get all members of a specific quiz (used to populate the avatar list on public quizzes)
const handleGetQuizMembers = async (req, res) => {
    const quizId = req.body.quizId || req.params.quizId;

    if (!quizId) {
        return res.status(400).json({ success: false, message: "شناسه آزمون ارسال نشده است" });
    }

    let decodedQuizId;
    try {
        decodedQuizId = decodeQuizId(quizId);
    } catch (err) {
        return res.status(400).json({ success: false, message: "شناسه آزمون نامعتبر است" });
    }

    let connection;
    try {
        connection = await pool.getConnection();

        // Join quiz_members with tam24_users to retrieve name and avatar
        // Left join with quiz_results to calculate score and order rank
        const sql = `
            SELECT 
                u.id, 
                u.first_name, 
                u.last_name, 
                u.avatar_url,
                qm.role,
                qr.total_score AS score
            FROM quiz_members qm
            JOIN tam24_users u ON qm.user_id = u.id
            LEFT JOIN quiz_results qr ON qm.quiz_id = qr.quiz_id AND qm.user_id = qr.user_id
            WHERE qm.quiz_id = ?
        `;

        const [rows] = await connection.query(sql, [decodedQuizId]);

        // Sort members by score descending (users without a finished result get fallback score of -1)
        const sorted = rows.sort((a, b) => {
            const scoreA = a.score !== null ? Number(a.score) : -1;
            const scoreB = b.score !== null ? Number(b.score) : -1;
            return scoreB - scoreA;
        });

        const currentUserId = req.user?.id;

        const members = sorted.map((m, index) => ({
            id: m.id,
            userId: m.id,
            fullName: `${m.first_name || ''} ${m.last_name || ''}`.trim() || "کاربر ناشناس",
            avatar: m.avatar_url || null,
            role: m.role,
            score: m.score,
            rank: m.score !== null ? index + 1 : null,
            isSelf: currentUserId ? (Number(m.id) === Number(currentUserId)) : false
        }));

        return res.json({ success: true, result: members });
    } catch (error) {
        console.error("❌ SQL Error in handleGetQuizMembers:", error);
        return res.status(500).json({ success: false, message: "خطا در دریافت اعضای آزمون" });
    } finally {
        if (connection) connection.release();
    }
};

// Get the result of a specific user for a specific quiz (used when clicking dynamic avatars)
const handleGetQuizResultByUserAndQuiz = async (req, res) => {
    let connection;
    try {
        const { userId, quizId } = req.body;

        if (!userId || !quizId) {
            return res.status(400).json({ error: "اطلاعات ارسالی ناقص است." });
        }

        const decodedQuizId = decodeQuizId(quizId);
        const targetUserId = Number(userId);

        if (!decodedQuizId || isNaN(targetUserId)) {
            return res.status(400).json({ error: "اطلاعات ارسالی نامعتبر است." });
        }

        connection = await pool.getConnection();

        // Retrieve quiz result record by quiz and user
        const [rows] = await connection.query(`
            SELECT
                r.id,
                r.quiz_id,
                r.user_id,
                r.correct_count,
                r.incorrect_count,
                r.unanswered_count,
                r.accuracy_rate,
                r.total_score,
                r.total_time_spent,
                r.summary_json,
                r.result_data_json,
                r.created_at,
                u.avatar_url
            FROM quiz_results r
            LEFT JOIN tam24_users u ON u.id = r.user_id
            WHERE r.quiz_id = ?
              AND r.user_id = ?
            LIMIT 1
        `, [decodedQuizId, targetUserId]);

        if (rows.length === 0) {
            return res.status(404).json({ error: "کاربر هنوز این آزمون را تمام نکرده است." });
        }

        const row = rows[0];
        const result = {
            id: row.id,
            quizId: row.quiz_id,
            userId: row.user_id,
            avatarUrl: row.avatar_url || null,
            correctCount: row.correct_count,
            incorrectCount: row.incorrect_count,
            unansweredCount: row.unanswered_count,
            accuracyRate: row.accuracy_rate,
            score: row.total_score,
            total_time_spent: row.total_time_spent,
            summary: safeJsonParse(row.summary_json, {}),
            resultData: safeJsonParse(row.result_data_json, []),
            createdAt: row.created_at
        };

        const rawResultData = result.resultData || {};
        const evaluation = rawResultData.evaluation && typeof rawResultData.evaluation === 'object'
            ? rawResultData.evaluation
            : {};
        const submission = rawResultData.submission && typeof rawResultData.submission === 'object'
            ? rawResultData.submission
            : {};

        const submittedAnswers =
            submission.submittedAnswers && typeof submission.submittedAnswers === 'object'
                ? submission.submittedAnswers
                : {};

        const questionTimes =
            submission.questionTimes && typeof submission.questionTimes === 'object'
                ? submission.questionTimes
                : {};

        const selectionLog = Array.isArray(submission.selectionLog)
            ? submission.selectionLog
            : [];

        const questionIds = Object.keys(evaluation).filter((key) => /^\d+$/.test(key));

        // Hydrate questions details (texts and options)
        if (questionIds.length > 0) {
            const placeholders = questionIds.map(() => '?').join(',');

            const [questions] = await connection.query(
                `
                SELECT 
                    q.id AS question_id,
                    q.question_text,
                    o.id AS option_id,
                    o.option_text
                FROM questions_tam24 q
                LEFT JOIN options_tam24 o ON q.id = o.question_id
                WHERE q.id IN (${placeholders})
                `,
                questionIds
            );

            const questionDetailsMap = {};

            for (const row of questions) {
                if (!questionDetailsMap[row.question_id]) {
                    questionDetailsMap[row.question_id] = {
                        question_text: row.question_text || "متن سوال یافت نشد",
                        options: [],
                    };
                }

                if (row.option_id) {
                    questionDetailsMap[row.question_id].options.push({
                        id: row.option_id,
                        text: row.option_text,
                    });
                }
            }

            await attachQuestionImages(connection, questionIds, questionDetailsMap);

            for (const qId of questionIds) {
                const details = questionDetailsMap[qId] || {
                    question_text: "متن سوال یافت نشد",
                    options: [],
                    images: [],
                };

                evaluation[qId] = {
                    ...evaluation[qId],
                    question_text: details.question_text,
                    options: details.options,
                    images: details.images || [],
                    selected_option_id:
                        evaluation[qId]?.selected_option_id ??
                        submittedAnswers[qId] ??
                        null,
                    is_answered:
                        typeof evaluation[qId]?.is_answered === 'boolean'
                            ? evaluation[qId].is_answered
                            : submittedAnswers[qId] != null,
                    time_spent_ms:
                        Number.isFinite(Number(questionTimes[qId]))
                            ? Number(questionTimes[qId])
                            : 0,
                };
            }
        }

        const formattedResult = {
            id: encodeResultId(result.id),
            quizId: encodeQuizId(result.quizId),
            userId: result.userId,
            avatarUrl: result.avatarUrl || null,
            correctCount: result.correctCount,
            incorrectCount: result.incorrectCount,
            unansweredCount: result.unansweredCount || 0,
            accuracyRate: result.accuracyRate,
            score: result.score,
            total_time_spent:
                Number.isFinite(Number(result.total_time_spent)) && Number(result.total_time_spent) > 0
                    ? Number(result.total_time_spent)
                    : Number(submission.totalTimeSpent) || 0,
            summary: result.summary,
            resultData: {
                evaluation,
                submission: {
                    ...submission,
                    totalTimeSpent: Number(submission.totalTimeSpent) || 0,
                    questionTimes,
                    selectionLog,
                    submittedAnswers,
                },
            },
        };

        return res.status(200).json(formattedResult);
    } catch (error) {
        console.error("Error in handleGetQuizResultByUserAndQuiz:", error);
        return res.status(500).json({ error: "خطای سرور در دریافت نتیجه آزمون کاربر." });
    } finally {
        if (connection) connection.release();
    }
};

async function handleInternalFinishQuiz(req, res) {
    const { quizId } = req.params;

    const decodedQuizId = decodeQuizId(quizId);
    let connection;

    try {
        connection = await pool.getConnection();

        const [result] = await connection.execute(
            `UPDATE quizzes SET status = 'completed' WHERE id = ?`,
            [decodedQuizId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Quiz not found.' });
        }

        return res.status(200).json({ success: true });

    } catch (error) {
        console.error('Error in handleInternalFinishQuiz:', error);
        return res.status(500).json({ error: 'Internal server error.' });
    } finally {
        if (connection) connection.release();
    }
}


async function handleFinishQuiz(req, res) {
    const { quizId } = req.body;

    const decodedQuizId = decodeQuizId(quizId);
    let connection;

    try {
        connection = await pool.getConnection();

        const [result] = await connection.execute(
            `UPDATE quizzes SET status = 'completed' WHERE id = ?`,
            [decodedQuizId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Quiz not found.' });
        }

        return res.status(200).json({ success: true });

    } catch (error) {
        console.error('Error in handleInternalFinishQuiz:', error);
        return res.status(500).json({ error: 'Internal server error.' });
    } finally {
        if (connection) connection.release();
    }
}



module.exports = {
    generateCode,
    handleGetSubjects,
    handleGetGradesBySubjects,     // به روز شده
    handleGetChaptersBySubjects,   // به روز شده
    handleGetMabahesByChapters,    // به روز شده
    handleSearchBankQuestions,
    handleGetBankQuestionAnswer,
    handleCreateQuiz,
    handleGetQuizByShareCode,
    handleGetQuizMetadata,
    handleGetQuizQuestions,
    handleCheckUserMember,
    handleSubmitQuizAnswers,
    handleGetQuizPreviewState,
    handleAddQuizMember,
    handleInternalGradeQuiz,
    handleInternalFinishQuiz,
    handleGetQuizResult,
    handleFinishQuiz,
    getQuizResultById,
    handleGetQuizMembers,
    handleGetQuizResultByUserAndQuiz,
    handleInternalSaveQuizResult

};
